import { CalculationMethod, Coordinates, Madhab, PrayerTimes, Qibla } from "adhan";

export const METHODS = [
  { id: "Karachi", label: "Karachi" },
  { id: "MuslimWorldLeague", label: "Muslim World League" },
  { id: "Egyptian", label: "Egyptian" },
  { id: "UmmAlQura", label: "Umm al-Qura" },
  { id: "NorthAmerica", label: "North America" },
] as const;

export type MethodId = (typeof METHODS)[number]["id"];
export type AsrId = "Hanafi" | "Shafi";

export const SALAH = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;
export type SalahName = (typeof SALAH)[number];
export type MarkName = SalahName | "Sunrise";

export type Slot = { name: MarkName; at: Date };

const builders: Record<MethodId, () => ReturnType<typeof CalculationMethod.Karachi>> = {
  Karachi: () => CalculationMethod.Karachi(),
  MuslimWorldLeague: () => CalculationMethod.MuslimWorldLeague(),
  Egyptian: () => CalculationMethod.Egyptian(),
  UmmAlQura: () => CalculationMethod.UmmAlQura(),
  NorthAmerica: () => CalculationMethod.NorthAmerica(),
};

export function isMethod(value: string): value is MethodId {
  return METHODS.some((m) => m.id === value);
}

export function methodLabel(id: MethodId): string {
  return METHODS.find((m) => m.id === id)?.label ?? id;
}

export function daySchedule(
  latitude: number,
  longitude: number,
  method: MethodId,
  asr: AsrId,
  date: Date,
): Slot[] {
  const params = builders[method]();
  params.madhab = asr === "Shafi" ? Madhab.Shafi : Madhab.Hanafi;
  const times = new PrayerTimes(new Coordinates(latitude, longitude), date, params);
  const slots: Slot[] = [
    { name: "Fajr", at: times.fajr },
    { name: "Sunrise", at: times.sunrise },
    { name: "Dhuhr", at: times.dhuhr },
    { name: "Asr", at: times.asr },
    { name: "Maghrib", at: times.maghrib },
    { name: "Isha", at: times.isha },
  ];
  if (slots.some((s) => Number.isNaN(s.at.getTime()))) {
    throw new Error("Prayer times could not be calculated for this location.");
  }
  return slots;
}

export type Agenda = {
  today: Slot[];
  nextSalah: Slot;
  sunriseBefore: Slot | null;
  previous: Slot;
  qibla: number;
};

function shiftDay(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, 12, 0, 0, 0);
}

export function agenda(
  latitude: number,
  longitude: number,
  method: MethodId,
  asr: AsrId,
  now: Date,
): Agenda {
  const today = daySchedule(latitude, longitude, method, asr, now);
  const span = [
    ...daySchedule(latitude, longitude, method, asr, shiftDay(now, -1)),
    ...today,
    ...daySchedule(latitude, longitude, method, asr, shiftDay(now, 1)),
  ].sort((a, b) => a.at.getTime() - b.at.getTime());

  const future = span.filter((s) => s.at.getTime() > now.getTime());
  const nextSalah = future.find((s) => s.name !== "Sunrise") ?? span[span.length - 1];
  const nextIndex = span.findIndex((s) => s.at.getTime() === nextSalah.at.getTime() && s.name === nextSalah.name);
  const previous = span[Math.max(0, nextIndex - 1)] ?? nextSalah;
  const sunriseBefore =
    future.find((s) => s.name === "Sunrise" && s.at.getTime() < nextSalah.at.getTime()) ?? null;

  return {
    today,
    nextSalah,
    sunriseBefore,
    previous,
    qibla: Qibla(new Coordinates(latitude, longitude)),
  };
}

export function formatClock(date: Date): string {
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(date);
}

export function formatRemaining(ms: number): string {
  const safe = Math.max(0, ms);
  const total = Math.floor(safe / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

export function formatCivil(date: Date): string {
  return new Intl.DateTimeFormat("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(date);
}

export function formatHijri(date: Date): string {
  try {
    return new Intl.DateTimeFormat("en-GB-u-ca-islamic", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date);
  } catch {
    return "";
  }
}

const COMPASS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"] as const;

export function compassPoint(degrees: number): string {
  const norm = ((degrees % 360) + 360) % 360;
  return COMPASS[Math.round(norm / 45) % 8] ?? "N";
}

export function parseClock(value: string | undefined): { hour: number; minute: number } | null {
  if (!value) return null;
  const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (!Number.isInteger(hour) || !Number.isInteger(minute)) return null;
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return { hour, minute };
}

export function jamaatOn(date: Date, value: string | undefined): Date | null {
  const parsed = parseClock(value);
  if (!parsed) return null;
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), parsed.hour, parsed.minute, 0, 0);
}
