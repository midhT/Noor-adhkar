export type Verse = {
  arabic: string;
  translation: string;
  reference: string;
};

export const verses: Verse[] = [
  {
    arabic: "وَمَا الْحَيَاةُ الدُّنْيَا إِلَّا مَتَاعُ الْغُرُورِ",
    translation: "The life of this world is only the enjoyment of delusion.",
    reference: "Quran 3:185",
  },
  {
    arabic: "وَاللَّهُ خَيْرُ الْمَاكِرِينَ",
    translation: "And Allah is the best of planners.",
    reference: "Quran 3:54",
  },
  {
    arabic: "وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ",
    translation: "My success is only through Allah.",
    reference: "Quran 11:88",
  },
  {
    arabic: "لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا",
    translation: "Do not grieve; indeed Allah is with us.",
    reference: "Quran 9:40",
  },
  {
    arabic: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا",
    translation: "For indeed, with hardship comes ease.",
    reference: "Quran 94:5",
  },
  {
    arabic: "إِنَّ مَعَ الْعُسْرِ يُسْرًا",
    translation: "Indeed, with hardship comes ease.",
    reference: "Quran 94:6",
  },
  {
    arabic: "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
    translation: "Allah does not burden a soul beyond what it can bear.",
    reference: "Quran 2:286",
  },
  {
    arabic: "وَهُوَ مَعَكُمْ أَيْنَ مَا كُنْتُمْ",
    translation: "He is with you wherever you are.",
    reference: "Quran 57:4",
  },
  {
    arabic: "أَلَيْسَ اللَّهُ بِكَافٍ عَبْدَهُ",
    translation: "Is Allah not sufficient for His servant?",
    reference: "Quran 39:36",
  },
  {
    arabic: "وَلَا تَيْأَسُوا مِنْ رَوْحِ اللَّهِ",
    translation: "Do not despair of relief from Allah.",
    reference: "Quran 12:87",
  },
  {
    arabic: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
    translation: "Indeed, Allah is with the patient.",
    reference: "Quran 2:153",
  },
  {
    arabic: "فَاذْكُرُونِي أَذْكُرْكُمْ",
    translation: "So remember Me; I will remember you.",
    reference: "Quran 2:152",
  },
  {
    arabic: "وَقُلْ رَبِّ زِدْنِي عِلْمًا",
    translation: "And say: My Lord, increase me in knowledge.",
    reference: "Quran 20:114",
  },
  {
    arabic: "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
    translation: "Allah is sufficient for us, and He is the best disposer of affairs.",
    reference: "Quran 3:173",
  },
  {
    arabic: "إِنَّ اللَّهَ يُحِبُّ الْمُتَوَكِّلِينَ",
    translation: "Indeed, Allah loves those who rely upon Him.",
    reference: "Quran 3:159",
  },
];

export function verseOfDay(date: Date): Verse {
  return verses[date.getDate() % verses.length] ?? verses[0];
}

export const duas: Verse[] = [
  {
    arabic:
      "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    translation:
      "Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
    reference: "Al-Baqarah 2:201",
  },
  {
    arabic: "رَبِّ زِدْنِي عِلْمًا",
    translation: "My Lord, increase me in knowledge.",
    reference: "Ta-Ha 20:114",
  },
  {
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ",
    translation: "O Allah, I ask You for pardon and well-being.",
    reference: "Prophetic supplication; verify wording with a trusted source",
  },
  {
    arabic:
      "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ",
    translation:
      "Our Lord, do not let our hearts deviate after You have guided us, and grant us mercy from Yourself. Indeed, You are the Bestower.",
    reference: "Ali Imran 3:8",
  },
  {
    arabic: "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
    translation: "My Lord, expand for me my chest and ease my task for me.",
    reference: "Ta-Ha 20:25–26",
  },
  {
    arabic: "رَبَّنَا تَقَبَّلْ مِنَّا ۖ إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ",
    translation: "Our Lord, accept from us. Indeed, You are the Hearing, the Knowing.",
    reference: "Al-Baqarah 2:127",
  },
];

export const dhikrPresets = [
  "سُبْحَانَ اللَّهِ",
  "الْحَمْدُ لِلَّهِ",
  "اللَّهُ أَكْبَرُ",
  "لَا إِلَٰهَ إِلَّا اللَّهُ",
  "أَسْتَغْفِرُ اللَّهَ",
] as const;

export const DEFAULT_DHIKR = dhikrPresets[0];

export const cities = [
  { name: "Srinagar", lat: 34.0837, lon: 74.7973 },
  { name: "Delhi", lat: 28.6139, lon: 77.209 },
  { name: "Makkah", lat: 21.4225, lon: 39.8262 },
  { name: "Madinah", lat: 24.4672, lon: 39.6111 },
  { name: "Karachi", lat: 24.8607, lon: 67.0011 },
  { name: "London", lat: 51.5072, lon: -0.1276 },
] as const;
