import { daySchedule, jamaatOn, type AsrId, type MethodId, type SalahName } from "@/lib/noor/prayer";

const timers: number[] = [];

export function clearReminders(): void {
  while (timers.length > 0) {
    const id = timers.pop();
    if (id != null) window.clearTimeout(id);
  }
}

function notify(title: string, body: string): void {
  try {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body });
    }
  } catch {
    /* the page may be backgrounded without permission to construct one */
  }
}

export function armReminders(input: {
  latitude: number;
  longitude: number;
  method: MethodId;
  asr: AsrId;
  jamaat: Partial<Record<SalahName, string>>;
}): number {
  clearReminders();
  const now = new Date();
  let count = 0;

  for (let day = 0; day < 7; day += 1) {
    const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() + day, 12, 0, 0, 0);
    const slots = daySchedule(input.latitude, input.longitude, input.method, input.asr, date).filter(
      (slot) => slot.name !== "Sunrise",
    );

    for (const slot of slots) {
      if (slot.name === "Sunrise") continue;
      const name = slot.name;
      const delay = slot.at.getTime() - now.getTime();
      if (delay > 0) {
        timers.push(
          window.setTimeout(() => {
            notify(`Time for ${name}`, `It is time for ${name}.`);
          }, delay),
        );
        count += 1;
      }

      const jamaat = jamaatOn(date, input.jamaat[name]);
      if (!jamaat) continue;
      const jDelay = jamaat.getTime() - now.getTime();
      if (jDelay > 0) {
        timers.push(
          window.setTimeout(() => {
            notify(`${slot.name} Jamaat`, "Your saved mosque Jamaat time is approaching.");
          }, jDelay),
        );
        count += 1;
      }
    }
  }

  return count;
}
