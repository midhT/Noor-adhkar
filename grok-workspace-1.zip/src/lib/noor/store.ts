import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { DEFAULT_DHIKR } from "@/lib/noor/content";
import type { AsrId, MethodId, SalahName } from "@/lib/noor/prayer";

type JamaatMap = Partial<Record<SalahName, string>>;

type NoorState = {
  latitude: number | null;
  longitude: number | null;
  place: string;
  method: MethodId;
  asr: AsrId;
  count: number;
  dhikr: string;
  jamaat: JamaatMap;
  reminders: boolean;
  setPlace: (latitude: number, longitude: number, place: string) => void;
  setMethod: (method: MethodId) => void;
  setAsr: (asr: AsrId) => void;
  setCount: (count: number) => void;
  setDhikr: (dhikr: string) => void;
  setJamaat: (prayer: SalahName, time: string) => void;
  setReminders: (reminders: boolean) => void;
};

export const useNoor = create<NoorState>()(
  persist(
    (set) => ({
      latitude: null,
      longitude: null,
      place: "Set your location",
      method: "Karachi",
      asr: "Hanafi",
      count: 0,
      dhikr: DEFAULT_DHIKR,
      jamaat: {},
      reminders: false,
      setPlace: (latitude, longitude, place) => set({ latitude, longitude, place }),
      setMethod: (method) => set({ method }),
      setAsr: (asr) => set({ asr }),
      setCount: (count) => set({ count }),
      setDhikr: (dhikr) => set({ dhikr }),
      setJamaat: (prayer, time) =>
        set((state) => {
          const jamaat = { ...state.jamaat };
          if (!time) delete jamaat[prayer];
          else jamaat[prayer] = time;
          return { jamaat };
        }),
      setReminders: (reminders) => set({ reminders }),
    }),
    {
      name: "noor-4",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        latitude: state.latitude,
        longitude: state.longitude,
        place: state.place,
        method: state.method,
        asr: state.asr,
        count: state.count,
        dhikr: state.dhikr,
        jamaat: state.jamaat,
        reminders: state.reminders,
      }),
    },
  ),
);
