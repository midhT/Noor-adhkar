import { createFileRoute } from "@tanstack/react-router";
import { NoorApp } from "@/components/noor/NoorApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NoorApp />;
}
