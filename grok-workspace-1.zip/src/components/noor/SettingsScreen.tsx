import { useState } from "react";
import { Bell, BookMarked, ChevronRight, WifiOff } from "lucide-react";
import { armReminders } from "@/lib/noor/reminders";
import { METHODS, type AsrId, type MethodId, type SalahName } from "@/lib/noor/prayer";

export function SettingsScreen({
  method,
  asr,
  reminders,
  latitude,
  longitude,
  jamaat,
  onMethod,
  onAsr,
  onReminders,
  onOpenDuas,
}: {
  method: MethodId;
  asr: AsrId;
  reminders: boolean;
  latitude: number | null;
  longitude: number | null;
  jamaat: Partial<Record<SalahName, string>>;
  onMethod: (method: MethodId) => void;
  onAsr: (asr: AsrId) => void;
  onReminders: (on: boolean) => void;
  onOpenDuas: () => void;
}) {
  const [note, setNote] = useState("");

  async function toggleReminders() {
    if (reminders) {
      onReminders(false);
      setNote("Reminders cleared.");
      return;
    }
    if (latitude == null || longitude == null) {
      setNote("Set your location in Salah first.");
      return;
    }
    if (!("Notification" in window)) {
      setNote("This browser cannot show notifications.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      onReminders(false);
      setNote("Permission not granted.");
      return;
    }
    const count = armReminders({ latitude, longitude, method, asr, jamaat });
    onReminders(true);
    setNote(
      `Scheduled ${count} upcoming prayer and Jamaat reminders. They fire while Noor stays open.`,
    );
  }

  return (
    <div className="px-5 pt-6 pb-8">
      <h1 className="text-3xl font-medium">Settings</h1>
      <p className="mt-1 text-sm text-muted">Make Noor yours</p>

      <section className="mt-5 overflow-hidden rounded-3xl border border-line bg-surface">
        <label className="block px-4 py-4">
          <span className="block text-sm">Calculation method</span>
          <span className="block text-xs text-muted">Prayer-time convention</span>
          <select
            value={method}
            onChange={(event) => onMethod(event.target.value as MethodId)}
            className="mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-sm text-fg"
          >
            {METHODS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
        <div className="mx-4 h-px bg-line" />
        <label className="block px-4 py-4">
          <span className="block text-sm">Asr calculation</span>
          <span className="block text-xs text-muted">Juristic convention</span>
          <select
            value={asr}
            onChange={(event) => onAsr(event.target.value as AsrId)}
            className="mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-sm text-fg"
          >
            <option value="Hanafi">Hanafi</option>
            <option value="Shafi">Shafi‘i</option>
          </select>
        </label>
      </section>

      <section className="mt-3 overflow-hidden rounded-3xl border border-line bg-surface">
        <button
          type="button"
          aria-pressed={reminders}
          onClick={() => void toggleReminders()}
          className="flex w-full items-center gap-3 px-4 py-4 text-left"
        >
          <Bell className="size-5 shrink-0 text-muted" />
          <span className="min-w-0 flex-1">
            <span className="block text-sm">Prayer reminders</span>
            <span className="block text-xs text-muted">
              {reminders ? "On for the next seven days" : "Off · allow notifications to schedule"}
            </span>
          </span>
          <span
            aria-hidden="true"
            className={`relative h-7 w-12 shrink-0 rounded-full ${reminders ? "bg-fg" : "bg-ink"}`}
          >
            <span
              className={`absolute top-1 size-5 rounded-full ${
                reminders ? "right-1 bg-bg" : "left-1 bg-muted"
              }`}
            />
          </span>
        </button>
        {note ? <p className="px-4 pb-4 text-xs leading-relaxed text-muted">{note}</p> : null}
        <div className="mx-4 h-px bg-line" />
        <button type="button" onClick={onOpenDuas} className="flex w-full items-center gap-3 px-4 py-4 text-left">
          <BookMarked className="size-5 shrink-0 text-muted" />
          <span className="flex-1 text-sm">Duas library</span>
          <ChevronRight className="size-4 text-muted" />
        </button>
        <div className="mx-4 h-px bg-line" />
        <div className="flex items-start gap-3 px-4 py-4">
          <WifiOff className="mt-0.5 size-5 shrink-0 text-muted" />
          <div>
            <p className="text-sm">Offline-first</p>
            <p className="text-xs leading-relaxed text-muted">
              Your counter, Jamaat times and settings stay on this device.
            </p>
          </div>
        </div>
      </section>

      <p className="mt-8 text-center text-xs tracking-widest text-muted">NOOR 4.0 · BLACK / WHITE</p>
    </div>
  );
}
