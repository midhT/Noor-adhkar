import { useState } from "react";
import { MapPin, Pencil } from "lucide-react";
import { cities } from "@/lib/noor/content";
import {
  agenda,
  compassPoint,
  formatClock,
  methodLabel,
  parseClock,
  type AsrId,
  type MethodId,
  type SalahName,
  type Slot,
} from "@/lib/noor/prayer";
import { Field, Sheet, TextButton } from "@/components/noor/ui";

export function SalahScreen({
  now,
  latitude,
  longitude,
  place,
  method,
  asr,
  jamaat,
  onPlace,
  onJamaat,
}: {
  now: Date;
  latitude: number | null;
  longitude: number | null;
  place: string;
  method: MethodId;
  asr: AsrId;
  jamaat: Partial<Record<SalahName, string>>;
  onPlace: (latitude: number, longitude: number, place: string) => void;
  onJamaat: (prayer: SalahName, time: string) => void;
}) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [coordsOpen, setCoordsOpen] = useState(false);
  const [latDraft, setLatDraft] = useState("");
  const [lonDraft, setLonDraft] = useState("");
  const [jamaatPrayer, setJamaatPrayer] = useState<SalahName | null>(null);
  const [jamaatDraft, setJamaatDraft] = useState("");
  const [jamaatError, setJamaatError] = useState("");

  let slots: Slot[] = [];
  let nextName = "";
  let qibla = "";
  let calcError = "";

  if (latitude != null && longitude != null) {
    try {
      const plan = agenda(latitude, longitude, method, asr, now);
      slots = plan.today;
      nextName = plan.nextSalah.name;
      const bearing = Math.round(((plan.qibla % 360) + 360) % 360);
      qibla = `Qibla ${bearing}° ${compassPoint(plan.qibla)}`;
    } catch (caught) {
      calcError = caught instanceof Error ? caught.message : "Prayer times could not be calculated.";
    }
  }

  async function useLocation() {
    setBusy(true);
    setError("");
    try {
      if (!navigator.geolocation) {
        throw new Error("Location is not available in this browser. Enter coordinates manually.");
      }
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve,
          (err) => {
            if (err.code === err.PERMISSION_DENIED) {
              reject(new Error("Location permission not granted. Enter coordinates manually."));
              return;
            }
            reject(new Error("Location services are unavailable. Enter coordinates manually."));
          },
          { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 },
        );
      });
      onPlace(position.coords.latitude, position.coords.longitude, "This device");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Location could not be read.");
    } finally {
      setBusy(false);
    }
  }

  function openCoords() {
    setLatDraft(latitude == null ? "" : String(latitude));
    setLonDraft(longitude == null ? "" : String(longitude));
    setCoordsOpen(true);
    setError("");
  }

  function saveCoords() {
    const latText = latDraft.trim();
    const lonText = lonDraft.trim();
    const lat = Number(latText);
    const lon = Number(lonText);
    if (
      !latText ||
      !lonText ||
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      lat < -90 ||
      lat > 90 ||
      lon < -180 ||
      lon > 180
    ) {
      setError("Please enter valid latitude and longitude.");
      return;
    }
    onPlace(lat, lon, "Saved coordinates");
    setError("");
    setCoordsOpen(false);
  }

  function openJamaat(prayer: SalahName) {
    setJamaatPrayer(prayer);
    setJamaatDraft(jamaat[prayer] ?? "");
    setJamaatError("");
  }

  function saveJamaat() {
    if (!jamaatPrayer) return;
    const trimmed = jamaatDraft.trim();
    if (trimmed && !parseClock(trimmed)) {
      setJamaatError("Use 24-hour time, like 13:30.");
      return;
    }
    onJamaat(jamaatPrayer, trimmed);
    setJamaatPrayer(null);
  }

  return (
    <div className="px-5 pt-6 pb-8">
      <h1 className="text-3xl font-medium">Salah</h1>
      <p className="mt-1 text-sm text-muted">Prayer times and your local Jamaat schedule</p>

      <div className="mt-5 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => void useLocation()}
          disabled={busy}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-2xl border border-line text-sm font-medium disabled:opacity-60"
        >
          <MapPin className="size-4" />
          {busy ? "Locating" : "Location"}
        </button>
        <button
          type="button"
          onClick={openCoords}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-2xl border border-line text-sm font-medium"
        >
          Coordinates
        </button>
      </div>

      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {cities.map((city) => (
          <button
            key={city.name}
            type="button"
            onClick={() => {
              onPlace(city.lat, city.lon, city.name);
              setError("");
            }}
            className={`h-11 shrink-0 rounded-full border px-4 text-sm ${
              place === city.name ? "border-fg bg-ink text-fg" : "border-line text-muted"
            }`}
          >
            {city.name}
          </button>
        ))}
      </div>

      {!coordsOpen && (error || calcError) ? <p className="mt-3 text-sm">{error || calcError}</p> : null}

      {latitude != null && longitude != null ? (
        <p className="mt-4 text-xs text-muted tabular-nums">
          {place} · {latitude.toFixed(4)}, {longitude.toFixed(4)}
          {qibla ? ` · ${qibla}` : ""}
        </p>
      ) : null}

      {slots.length === 0 ? (
        <section className="mt-4 rounded-3xl border border-line bg-surface p-5 text-sm leading-relaxed">
          Set your location or enter coordinates to calculate prayer times.
        </section>
      ) : (
        <ul className="mt-4 flex flex-col gap-2">
          {slots.map((slot) => {
            const passed = slot.at.getTime() <= now.getTime();
            const isNext = slot.name === nextName && !passed;
            const saved = slot.name === "Sunrise" ? undefined : jamaat[slot.name];
            return (
              <li
                key={slot.name}
                className={`rounded-3xl border border-line px-4 py-3 ${isNext ? "bg-ink" : "bg-surface"}`}
              >
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-base">{slot.name}</p>
                    <p className="text-xs text-muted">
                      {slot.name === "Sunrise"
                        ? "Fajr time ends"
                        : saved
                          ? `Jamaat · ${saved}`
                          : "Jamaat not set"}
                    </p>
                  </div>
                  <p className={`text-base tabular-nums ${passed ? "text-muted" : ""}`}>{formatClock(slot.at)}</p>
                  {slot.name !== "Sunrise" ? (
                    <button
                      type="button"
                      aria-label={`Edit ${slot.name} Jamaat`}
                      onClick={() => {
                        if (slot.name !== "Sunrise") openJamaat(slot.name);
                      }}
                      className="grid size-11 place-items-center rounded-2xl text-muted"
                    >
                      <Pencil className="size-4" />
                    </button>
                  ) : (
                    <span className="size-11" />
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <p className="mt-4 text-xs leading-relaxed text-muted">
        {methodLabel(method)}
        {method === "Karachi" ? ", commonly used in South Asia" : ""}. Asr: {asr === "Shafi" ? "Shafi‘i" : "Hanafi"}.
        Change either in Settings — it updates these times.
      </p>

      <Sheet open={coordsOpen} title="Enter coordinates" onClose={() => setCoordsOpen(false)}>
        <Field label="Latitude" value={latDraft} onChange={setLatDraft} inputMode="decimal" placeholder="34.08" />
        <Field label="Longitude" value={lonDraft} onChange={setLonDraft} inputMode="decimal" placeholder="74.80" />
        {error ? <p className="mt-2 text-sm">{error}</p> : null}
        <div className="mt-4 flex justify-end gap-2">
          <TextButton onClick={() => setCoordsOpen(false)}>Cancel</TextButton>
          <TextButton tone="solid" onClick={saveCoords}>
            Save
          </TextButton>
        </div>
      </Sheet>

      <Sheet
        open={jamaatPrayer != null}
        title={jamaatPrayer ? `${jamaatPrayer} Jamaat` : "Jamaat"}
        onClose={() => setJamaatPrayer(null)}
      >
        <Field
          label="Mosque time, 24-hour"
          value={jamaatDraft}
          onChange={setJamaatDraft}
          inputMode="numeric"
          placeholder="13:30"
        />
        {jamaatError ? <p className="mt-2 text-sm">{jamaatError}</p> : null}
        <p className="mt-2 text-xs text-muted">Leave blank to clear.</p>
        <div className="mt-4 flex justify-end gap-2">
          <TextButton onClick={() => setJamaatPrayer(null)}>Cancel</TextButton>
          <TextButton tone="solid" onClick={saveJamaat}>
            Save
          </TextButton>
        </div>
      </Sheet>
    </div>
  );
}
