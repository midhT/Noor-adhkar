import { useState } from "react";
import { dhikrPresets } from "@/lib/noor/content";
import { Arabic, Field, Sheet, TextButton } from "@/components/noor/ui";

const GOAL = 33;

export function DhikrScreen({
  count,
  dhikr,
  onCount,
  onDhikr,
}: {
  count: number;
  dhikr: string;
  onCount: (count: number) => void;
  onDhikr: (dhikr: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(dhikr);
  const progress = (count % GOAL) / GOAL;
  const radius = 102;
  const circ = 2 * Math.PI * radius;
  const rounds = Math.floor(count / GOAL);

  function tap() {
    onCount(count + 1);
    if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
      navigator.vibrate(12);
    }
  }

  function save() {
    const next = draft.trim();
    if (!next) return;
    onDhikr(next);
    setOpen(false);
  }

  return (
    <div className="px-5 pt-6 pb-8">
      <h1 className="text-3xl font-medium">Dhikr</h1>
      <p className="mt-1 text-sm text-muted">A moment of remembrance</p>

      <Arabic className="mt-8 text-3xl">{dhikr}</Arabic>

      <p className="mt-6 text-center text-7xl font-light tabular-nums" aria-live="polite">
        {count}
      </p>
      <p className="text-center text-xs tracking-widest text-muted">COUNT</p>
      {rounds > 0 ? (
        <p className="mt-1 text-center text-xs text-muted">
          {rounds} {rounds === 1 ? "round" : "rounds"} of {GOAL}
        </p>
      ) : (
        <p className="mt-1 text-center text-xs text-muted">{GOAL} to a round</p>
      )}

      <div className="mt-6 flex justify-center">
        <button
          type="button"
          onClick={tap}
          aria-label="Count dhikr"
          className="relative grid size-64 place-items-center"
        >
          <svg viewBox="0 0 220 220" className="size-64" aria-hidden="true">
            <circle cx="110" cy="110" r={radius} className="fill-none stroke-line" strokeWidth="2" />
            <circle
              cx="110"
              cy="110"
              r={radius}
              className="fill-none stroke-fg"
              strokeWidth="2"
              strokeLinecap="round"
              strokeDasharray={`${circ * progress} ${circ}`}
              transform="rotate(-90 110 110)"
            />
          </svg>
          <span className="dhikr-shadow absolute grid size-44 place-items-center rounded-full border border-line bg-surface">
            <span className="text-xs tracking-widest text-muted">TAP</span>
          </span>
        </button>
      </div>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-1">
        {dhikrPresets.map((preset) => (
          <button
            key={preset}
            type="button"
            onClick={() => onDhikr(preset)}
            className={`h-11 shrink-0 rounded-full border px-4 font-arabic text-lg ${
              dhikr === preset ? "border-fg bg-ink" : "border-line text-muted"
            }`}
          >
            {preset}
          </button>
        ))}
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => {
            setDraft(dhikr);
            setOpen(true);
          }}
          className="h-11 rounded-2xl border border-line text-sm font-medium"
        >
          Change dhikr
        </button>
        <button
          type="button"
          onClick={() => onCount(0)}
          className="h-11 rounded-2xl border border-line text-sm font-medium"
        >
          Reset
        </button>
      </div>

      <Sheet open={open} title="Custom dhikr" onClose={() => setOpen(false)}>
        <Field label="Phrase" value={draft} onChange={setDraft} />
        <div className="mt-4 flex justify-end gap-2">
          <TextButton onClick={() => setOpen(false)}>Cancel</TextButton>
          <TextButton tone="solid" onClick={save}>
            Save
          </TextButton>
        </div>
      </Sheet>
    </div>
  );
}
