import { useMemo, useState } from "react";
import { verses } from "@/lib/noor/content";
import { Arabic } from "@/components/noor/ui";

export function QuranScreen() {
  const [query, setQuery] = useState("");
  const needle = query.trim().toLowerCase();
  const shown = useMemo(
    () =>
      needle
        ? verses.filter((verse) =>
            `${verse.arabic} ${verse.translation} ${verse.reference}`.toLowerCase().includes(needle),
          )
        : verses,
    [needle],
  );

  return (
    <div className="px-5 pt-6 pb-8">
      <h1 className="text-3xl font-medium">Quran</h1>
      <p className="mt-1 text-sm text-muted">A collection of verses for reflection</p>
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search verses"
        aria-label="Search verses"
        className="mt-5 h-12 w-full rounded-2xl border border-line bg-surface-2 px-4 text-base outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg"
      />
      {shown.length === 0 ? (
        <p className="mt-6 text-sm text-muted">Nothing matches that.</p>
      ) : (
        <ul className="mt-4 flex flex-col gap-3">
          {shown.map((verse) => (
            <li key={verse.reference + verse.arabic} className="rounded-3xl border border-line bg-surface p-5">
              <Arabic className="text-2xl">{verse.arabic}</Arabic>
              <p className="mt-3 text-center text-sm leading-relaxed text-pretty">{verse.translation}</p>
              <p className="mt-3 text-center text-xs text-muted">{verse.reference}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
