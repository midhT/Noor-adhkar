import { ChevronLeft } from "lucide-react";
import { duas } from "@/lib/noor/content";
import { Arabic } from "@/components/noor/ui";

export function DuasScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="px-5 pt-5 pb-8">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex h-11 items-center gap-1 text-sm text-muted"
      >
        <ChevronLeft className="size-4" />
        Settings
      </button>
      <h1 className="mt-3 text-3xl font-medium">Duas</h1>
      <p className="mt-1 text-sm text-muted">Supplications to keep close</p>
      <ul className="mt-5 flex flex-col gap-3">
        {duas.map((dua) => (
          <li key={dua.reference + dua.arabic} className="rounded-3xl border border-line bg-surface p-5">
            <Arabic className="text-2xl">{dua.arabic}</Arabic>
            <p className="mt-3 text-center text-sm leading-relaxed text-pretty">{dua.translation}</p>
            <p className="mt-3 text-center text-xs text-muted">{dua.reference}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
