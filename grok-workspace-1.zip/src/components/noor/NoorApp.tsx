import { useEffect, useState } from "react";
import { BookOpen, Fingerprint, LayoutGrid, MoonStar, SlidersHorizontal } from "lucide-react";
import { DhikrScreen } from "@/components/noor/DhikrScreen";
import { DuasScreen } from "@/components/noor/DuasScreen";
import { HomeScreen } from "@/components/noor/HomeScreen";
import { QuranScreen } from "@/components/noor/QuranScreen";
import { SalahScreen } from "@/components/noor/SalahScreen";
import { SettingsScreen } from "@/components/noor/SettingsScreen";
import { armReminders, clearReminders } from "@/lib/noor/reminders";
import { useNoor } from "@/lib/noor/store";

type Tab = "home" | "salah" | "dhikr" | "quran" | "settings";

const TABS: { id: Tab; label: string; icon: typeof LayoutGrid }[] = [
  { id: "home", label: "Home", icon: LayoutGrid },
  { id: "salah", label: "Salah", icon: MoonStar },
  { id: "dhikr", label: "Dhikr", icon: Fingerprint },
  { id: "quran", label: "Quran", icon: BookOpen },
  { id: "settings", label: "Settings", icon: SlidersHorizontal },
];

function useNow(active: boolean): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, [active]);
  return now;
}

export function NoorApp() {
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>("home");
  const [duas, setDuas] = useState(false);
  const [tick, setTick] = useState(0);
  const now = useNow(ready);

  const latitude = useNoor((s) => s.latitude);
  const longitude = useNoor((s) => s.longitude);
  const place = useNoor((s) => s.place);
  const method = useNoor((s) => s.method);
  const asr = useNoor((s) => s.asr);
  const count = useNoor((s) => s.count);
  const dhikr = useNoor((s) => s.dhikr);
  const jamaat = useNoor((s) => s.jamaat);
  const reminders = useNoor((s) => s.reminders);
  const setPlace = useNoor((s) => s.setPlace);
  const setMethod = useNoor((s) => s.setMethod);
  const setAsr = useNoor((s) => s.setAsr);
  const setCount = useNoor((s) => s.setCount);
  const setDhikr = useNoor((s) => s.setDhikr);
  const setJamaat = useNoor((s) => s.setJamaat);
  const setReminders = useNoor((s) => s.setReminders);

  useEffect(() => {
    let alive = true;
    const done = () => {
      if (alive) setReady(true);
    };
    const unsub = useNoor.persist.onFinishHydration(done);
    void useNoor.persist.rehydrate();
    if (useNoor.persist.hasHydrated()) done();
    const backup = window.setTimeout(done, 500);
    return () => {
      alive = false;
      unsub();
      window.clearTimeout(backup);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (!reminders || latitude == null || longitude == null) {
      clearReminders();
      return;
    }
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    armReminders({ latitude, longitude, method, asr, jamaat });
    return () => clearReminders();
  }, [ready, reminders, latitude, longitude, method, asr, jamaat, tick]);

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg text-fg">
        <div className="text-center">
          <p className="font-arabic text-5xl">ن</p>
          <p className="mt-3 text-xs tracking-widest text-muted">NOOR</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto min-h-dvh w-full max-w-md">
        <main className="pb-28">
          {duas ? (
            <DuasScreen
              onBack={() => {
                setDuas(false);
                setTab("settings");
              }}
            />
          ) : tab === "home" ? (
            <HomeScreen
              now={now}
              latitude={latitude}
              longitude={longitude}
              place={place}
              method={method}
              asr={asr}
              count={count}
              onRefresh={() => setTick((n) => n + 1)}
              onOpenSalah={() => setTab("salah")}
              onOpenDhikr={() => setTab("dhikr")}
              onOpenQuran={() => setTab("quran")}
            />
          ) : tab === "salah" ? (
            <SalahScreen
              now={now}
              latitude={latitude}
              longitude={longitude}
              place={place}
              method={method}
              asr={asr}
              jamaat={jamaat}
              onPlace={setPlace}
              onJamaat={setJamaat}
            />
          ) : tab === "dhikr" ? (
            <DhikrScreen count={count} dhikr={dhikr} onCount={setCount} onDhikr={setDhikr} />
          ) : tab === "quran" ? (
            <QuranScreen />
          ) : (
            <SettingsScreen
              method={method}
              asr={asr}
              reminders={reminders}
              latitude={latitude}
              longitude={longitude}
              jamaat={jamaat}
              onMethod={setMethod}
              onAsr={setAsr}
              onReminders={setReminders}
              onOpenDuas={() => setDuas(true)}
            />
          )}
        </main>
        <nav className="nav-pad fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface" aria-label="Primary">
          <div className="mx-auto grid max-w-md grid-cols-5">
            {TABS.map((item) => {
              const active = !duas && tab === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={active ? "page" : undefined}
                  onClick={() => {
                    setDuas(false);
                    setTab(item.id);
                  }}
                  className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${
                    active ? "text-fg" : "text-muted"
                  }`}
                >
                  <span className={`grid size-8 place-items-center rounded-xl ${active ? "bg-ink" : ""}`}>
                    <Icon className="size-4" />
                  </span>
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
