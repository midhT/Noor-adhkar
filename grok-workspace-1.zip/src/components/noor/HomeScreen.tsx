import { BookOpen, Fingerprint, LocateFixed, RefreshCw } from "lucide-react";
import { verseOfDay } from "@/lib/noor/content";
import {
  agenda,
  formatCivil,
  formatClock,
  formatHijri,
  formatRemaining,
  type AsrId,
  type MethodId,
} from "@/lib/noor/prayer";
import { Arabic } from "@/components/noor/ui";

export function HomeScreen({
  now,
  latitude,
  longitude,
  place,
  method,
  asr,
  count,
  onRefresh,
  onOpenSalah,
  onOpenDhikr,
  onOpenQuran,
}: {
  now: Date;
  latitude: number | null;
  longitude: number | null;
  place: string;
  method: MethodId;
  asr: AsrId;
  count: number;
  onRefresh: () => void;
  onOpenSalah: () => void;
  onOpenDhikr: () => void;
  onOpenQuran: () => void;
}) {
  const verse = verseOfDay(now);
  let nextName = "Location needed";
  let nextTime = "--:--";
  let remain = "";
  let sunrise = "";
  let progress = 0;
  let error = "";

  if (latitude != null && longitude != null) {
    try {
      const plan = agenda(latitude, longitude, method, asr, now);
      nextName = plan.nextSalah.name;
      nextTime = formatClock(plan.nextSalah.at);
      remain = formatRemaining(plan.nextSalah.at.getTime() - now.getTime());
      const span = plan.nextSalah.at.getTime() - plan.previous.at.getTime();
      const done = now.getTime() - plan.previous.at.getTime();
      progress = span > 0 ? Math.min(100, Math.max(0, (done / span) * 100)) : 0;
      if (plan.sunriseBefore) sunrise = `Sunrise ${formatClock(plan.sunriseBefore.at)}`;
    } catch (caught) {
      error = caught instanceof Error ? caught.message : "Prayer times could not be calculated.";
      nextName = "Unavailable";
    }
  }

  const hijri = formatHijri(now);

  return (
    <div className="px-5 pt-5 pb-8">
      <header className="flex items-center gap-3">
        <div className="grid size-11 place-items-center rounded-2xl border border-line font-arabic text-2xl">
          ن
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold tracking-widest">NOOR</p>
          <p className="text-xs text-muted">A quieter daily rhythm</p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          aria-label="Refresh"
          className="ml-auto grid size-11 place-items-center rounded-2xl text-muted"
        >
          <RefreshCw className="size-5" />
        </button>
      </header>

      <p className="mt-8 text-sm text-muted">{formatCivil(now)}</p>
      {hijri ? <p className="mt-1 text-xs text-muted">{hijri}</p> : null}
      <h1 className="mt-2 text-3xl font-medium text-balance">Assalamu Alaikum</h1>

      <section className="mt-5 rounded-3xl border border-line bg-surface p-5">
        <p className="flex items-center gap-2 text-sm text-muted">
          <LocateFixed className="size-4" />
          {place}
        </p>
        <p className="mt-5 text-xs tracking-widest text-muted">UP NEXT</p>
        <div className="mt-1 flex items-end justify-between gap-3">
          <h2 className="text-4xl font-light">{nextName}</h2>
          <p className="pb-1 text-xl text-muted tabular-nums">{nextTime}</p>
        </div>
        {remain ? <p className="mt-2 text-sm text-muted tabular-nums">in {remain}</p> : null}
        {sunrise ? <p className="mt-1 text-sm text-muted">{sunrise}</p> : null}
        {error ? <p className="mt-2 text-sm">{error}</p> : null}
        {latitude != null ? (
          <div className="mt-4 h-1 overflow-hidden rounded-full bg-ink" aria-hidden="true">
            <div className="h-full bg-fg" style={{ width: `${progress}%` }} />
          </div>
        ) : null}
        <button
          type="button"
          onClick={onOpenSalah}
          className="mt-5 h-11 w-full rounded-2xl border border-line text-sm font-medium tracking-wide"
        >
          View prayer times
        </button>
      </section>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={onOpenDhikr}
          className="rounded-3xl border border-line bg-surface p-4 text-left"
        >
          <Fingerprint className="size-5 text-muted" />
          <p className="mt-4 text-3xl font-light tabular-nums">{count}</p>
          <p className="mt-1 text-xs tracking-widest text-muted">DHIKR TODAY</p>
        </button>
        <button
          type="button"
          onClick={onOpenQuran}
          className="rounded-3xl border border-line bg-surface p-4 text-left"
        >
          <BookOpen className="size-5 text-muted" />
          <p className="mt-4 text-3xl font-light">Read</p>
          <p className="mt-1 text-xs tracking-widest text-muted">DAILY VERSE</p>
        </button>
      </div>

      <p className="mt-7 text-xs tracking-widest text-muted">A VERSE TO CARRY</p>
      <section className="mt-3 rounded-3xl border border-line bg-surface p-5">
        <Arabic className="text-3xl">{verse.arabic}</Arabic>
        <p className="mt-4 text-center text-sm leading-relaxed text-pretty">{verse.translation}</p>
        <p className="mt-3 text-center text-xs text-muted">{verse.reference}</p>
      </section>
    </div>
  );
}
