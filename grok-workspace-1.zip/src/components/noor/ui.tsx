import type { ReactNode } from "react";

export function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 sm:items-center"
      onClick={onClose}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="w-full max-w-md rounded-t-3xl border border-line bg-surface p-5 sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 className="text-lg font-medium">{title}</h2>
        {children}
      </div>
    </div>
  );
}

export function Field({
  label,
  value,
  onChange,
  placeholder,
  inputMode,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  inputMode?: "decimal" | "numeric" | "text";
}) {
  return (
    <label className="mt-3 block text-sm text-muted">
      {label}
      <input
        value={value}
        inputMode={inputMode}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 h-12 w-full rounded-2xl bg-surface-2 px-4 text-base text-fg outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg"
      />
    </label>
  );
}

export function TextButton({
  children,
  onClick,
  tone = "ghost",
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "ghost" | "solid";
}) {
  const toneClass =
    tone === "solid"
      ? "bg-fg text-bg"
      : "border border-line bg-transparent text-fg";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex h-11 items-center justify-center rounded-2xl px-4 text-sm font-medium ${toneClass}`}
    >
      {children}
    </button>
  );
}

export function Arabic({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <p lang="ar" dir="rtl" className={`font-arabic text-center leading-relaxed text-balance ${className}`}>
      {children}
    </p>
  );
}
