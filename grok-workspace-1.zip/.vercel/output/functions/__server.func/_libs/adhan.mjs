//#region node_modules/adhan/lib/esm/Madhab.js
var Madhab = {
	Shafi: "shafi",
	Hanafi: "hanafi"
};
function shadowLength(madhab) {
	switch (madhab) {
		case Madhab.Shafi: return 1;
		case Madhab.Hanafi: return 2;
		default: throw "Invalid Madhab";
	}
}
//#endregion
//#region node_modules/adhan/lib/esm/HighLatitudeRule.js
var HighLatitudeRule = {
	MiddleOfTheNight: "middleofthenight",
	SeventhOfTheNight: "seventhofthenight",
	TwilightAngle: "twilightangle",
	recommended(coordinates) {
		if (coordinates.latitude > 48) return HighLatitudeRule.SeventhOfTheNight;
		else return HighLatitudeRule.MiddleOfTheNight;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/Coordinates.js
var Coordinates = class {
	constructor(latitude, longitude) {
		this.latitude = latitude;
		this.longitude = longitude;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/Rounding.js
var Rounding = {
	Nearest: "nearest",
	Up: "up",
	None: "none"
};
//#endregion
//#region node_modules/adhan/lib/esm/DateUtils.js
function dateByAddingDays(date, days) {
	const year = date.getFullYear();
	const month = date.getMonth();
	const day = date.getDate() + days;
	const hours = date.getHours();
	const minutes = date.getMinutes();
	const seconds = date.getSeconds();
	return new Date(year, month, day, hours, minutes, seconds);
}
function dateByAddingMinutes(date, minutes) {
	return dateByAddingSeconds(date, minutes * 60);
}
function dateByAddingSeconds(date, seconds) {
	return new Date(date.getTime() + seconds * 1e3);
}
function roundedMinute(date, rounding = Rounding.Nearest) {
	const seconds = date.getUTCSeconds();
	let offset = seconds >= 30 ? 60 - seconds : -1 * seconds;
	if (rounding === Rounding.Up) offset = 60 - seconds;
	else if (rounding === Rounding.None) offset = 0;
	return dateByAddingSeconds(date, offset);
}
function isLeapYear(year) {
	if (year % 4 !== 0) return false;
	if (year % 100 === 0 && year % 400 !== 0) return false;
	return true;
}
function dayOfYear(date) {
	let returnedDayOfYear = 0;
	const months = [
		31,
		isLeapYear(date.getFullYear()) ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	];
	for (let i = 0; i < date.getMonth(); i++) returnedDayOfYear += months[i];
	returnedDayOfYear += date.getDate();
	return returnedDayOfYear;
}
function isValidDate(date) {
	return date instanceof Date && !isNaN(date.valueOf());
}
//#endregion
//#region node_modules/adhan/lib/esm/MathUtils.js
function degreesToRadians(degrees) {
	return degrees * Math.PI / 180;
}
function radiansToDegrees(radians) {
	return radians * 180 / Math.PI;
}
function normalizeToScale(num, max) {
	return num - max * Math.floor(num / max);
}
function unwindAngle(angle) {
	return normalizeToScale(angle, 360);
}
function quadrantShiftAngle(angle) {
	if (angle >= -180 && angle <= 180) return angle;
	return angle - 360 * Math.round(angle / 360);
}
//#endregion
//#region node_modules/adhan/lib/esm/Shafaq.js
var Shafaq = {
	General: "general",
	Ahmer: "ahmer",
	Abyad: "abyad"
};
//#endregion
//#region node_modules/adhan/lib/esm/Astronomical.js
var Astronomical = {
	meanSolarLongitude(julianCentury) {
		const T = julianCentury;
		const term1 = 280.4664567;
		const term2 = 36000.76983 * T;
		const term3 = 3032e-7 * Math.pow(T, 2);
		return unwindAngle(term1 + term2 + term3);
	},
	meanLunarLongitude(julianCentury) {
		return unwindAngle(218.3165 + 481267.8813 * julianCentury);
	},
	ascendingLunarNodeLongitude(julianCentury) {
		const T = julianCentury;
		const term1 = 125.04452;
		const term2 = 1934.136261 * T;
		const term3 = .0020708 * Math.pow(T, 2);
		const term4 = Math.pow(T, 3) / 45e4;
		return unwindAngle(term1 - term2 + term3 + term4);
	},
	meanSolarAnomaly(julianCentury) {
		const T = julianCentury;
		const term1 = 357.52911;
		const term2 = 35999.05029 * T;
		const term3 = 1537e-7 * Math.pow(T, 2);
		return unwindAngle(term1 + term2 - term3);
	},
	solarEquationOfTheCenter(julianCentury, meanAnomaly) {
		const T = julianCentury;
		const Mrad = degreesToRadians(meanAnomaly);
		const term1 = (1.914602 - .004817 * T - 14e-6 * Math.pow(T, 2)) * Math.sin(Mrad);
		const term2 = (.019993 - 101e-6 * T) * Math.sin(2 * Mrad);
		const term3 = 289e-6 * Math.sin(3 * Mrad);
		return term1 + term2 + term3;
	},
	apparentSolarLongitude(julianCentury, meanLongitude) {
		const T = julianCentury;
		const longitude = meanLongitude + Astronomical.solarEquationOfTheCenter(T, Astronomical.meanSolarAnomaly(T));
		const Omega = 125.04 - 1934.136 * T;
		return unwindAngle(longitude - .00569 - .00478 * Math.sin(degreesToRadians(Omega)));
	},
	meanObliquityOfTheEcliptic(julianCentury) {
		const T = julianCentury;
		const term1 = 23.439291;
		const term2 = .013004167 * T;
		const term3 = 1.639e-7 * Math.pow(T, 2);
		const term4 = 5.036e-7 * Math.pow(T, 3);
		return term1 - term2 - term3 + term4;
	},
	apparentObliquityOfTheEcliptic(julianCentury, meanObliquityOfTheEcliptic) {
		const T = julianCentury;
		const Epsilon0 = meanObliquityOfTheEcliptic;
		const O = 125.04 - 1934.136 * T;
		return Epsilon0 + .00256 * Math.cos(degreesToRadians(O));
	},
	meanSiderealTime(julianCentury) {
		const T = julianCentury;
		const JD = T * 36525 + 2451545;
		const term1 = 280.46061837;
		const term2 = 360.98564736629 * (JD - 2451545);
		const term3 = 387933e-9 * Math.pow(T, 2);
		const term4 = Math.pow(T, 3) / 3871e4;
		return unwindAngle(term1 + term2 + term3 - term4);
	},
	nutationInLongitude(julianCentury, solarLongitude, lunarLongitude, ascendingNode) {
		const L0 = solarLongitude;
		const Lp = lunarLongitude;
		const Omega = ascendingNode;
		const term1 = -17.2 / 3600 * Math.sin(degreesToRadians(Omega));
		const term2 = 1.32 / 3600 * Math.sin(2 * degreesToRadians(L0));
		const term3 = .23 / 3600 * Math.sin(2 * degreesToRadians(Lp));
		const term4 = .21 / 3600 * Math.sin(2 * degreesToRadians(Omega));
		return term1 - term2 - term3 + term4;
	},
	nutationInObliquity(julianCentury, solarLongitude, lunarLongitude, ascendingNode) {
		const L0 = solarLongitude;
		const Lp = lunarLongitude;
		const Omega = ascendingNode;
		const term1 = 9.2 / 3600 * Math.cos(degreesToRadians(Omega));
		const term2 = .57 / 3600 * Math.cos(2 * degreesToRadians(L0));
		const term3 = .1 / 3600 * Math.cos(2 * degreesToRadians(Lp));
		const term4 = .09 / 3600 * Math.cos(2 * degreesToRadians(Omega));
		return term1 + term2 + term3 - term4;
	},
	altitudeOfCelestialBody(observerLatitude, declination, localHourAngle) {
		const Phi = observerLatitude;
		const delta = declination;
		const H = localHourAngle;
		const term1 = Math.sin(degreesToRadians(Phi)) * Math.sin(degreesToRadians(delta));
		const term2 = Math.cos(degreesToRadians(Phi)) * Math.cos(degreesToRadians(delta)) * Math.cos(degreesToRadians(H));
		return radiansToDegrees(Math.asin(term1 + term2));
	},
	approximateTransit(longitude, siderealTime, rightAscension) {
		const L = longitude;
		const Theta0 = siderealTime;
		const m0 = normalizeToScale((rightAscension + L * -1 - Theta0) / 360, 1);
		const expectedTransit = normalizeToScale((12 - L / 15) / 24, 1);
		if (m0 - expectedTransit > .5) return m0 - 1;
		else if (expectedTransit - m0 > .5) return m0 + 1;
		else return m0;
	},
	correctedTransit(approximateTransit, longitude, siderealTime, rightAscension, previousRightAscension, nextRightAscension) {
		const m0 = approximateTransit;
		const L = longitude;
		const Theta0 = siderealTime;
		const a2 = rightAscension;
		const a1 = previousRightAscension;
		const a3 = nextRightAscension;
		const Lw = L * -1;
		const Theta = unwindAngle(Theta0 + 360.985647 * m0);
		const a = unwindAngle(Astronomical.interpolateAngles(a2, a1, a3, m0));
		return (m0 + quadrantShiftAngle(Theta - Lw - a) / -360) * 24;
	},
	correctedHourAngle(approximateTransit, angle, coordinates, afterTransit, siderealTime, rightAscension, previousRightAscension, nextRightAscension, declination, previousDeclination, nextDeclination) {
		const m0 = approximateTransit;
		const h0 = angle;
		const Theta0 = siderealTime;
		const a2 = rightAscension;
		const a1 = previousRightAscension;
		const a3 = nextRightAscension;
		const d2 = declination;
		const d1 = previousDeclination;
		const d3 = nextDeclination;
		const Lw = coordinates.longitude * -1;
		const term1 = Math.sin(degreesToRadians(h0)) - Math.sin(degreesToRadians(coordinates.latitude)) * Math.sin(degreesToRadians(d2));
		const term2 = Math.cos(degreesToRadians(coordinates.latitude)) * Math.cos(degreesToRadians(d2));
		const H0 = radiansToDegrees(Math.acos(term1 / term2));
		const m = afterTransit ? m0 + H0 / 360 : m0 - H0 / 360;
		const Theta = unwindAngle(Theta0 + 360.985647 * m);
		const a = unwindAngle(Astronomical.interpolateAngles(a2, a1, a3, m));
		const delta = Astronomical.interpolate(d2, d1, d3, m);
		const H = Theta - Lw - a;
		return (m + (Astronomical.altitudeOfCelestialBody(coordinates.latitude, delta, H) - h0) / (360 * Math.cos(degreesToRadians(delta)) * Math.cos(degreesToRadians(coordinates.latitude)) * Math.sin(degreesToRadians(H)))) * 24;
	},
	interpolate(y2, y1, y3, n) {
		const a = y2 - y1;
		const b = y3 - y2;
		const c = b - a;
		return y2 + n / 2 * (a + b + n * c);
	},
	interpolateAngles(y2, y1, y3, n) {
		const a = unwindAngle(y2 - y1);
		const b = unwindAngle(y3 - y2);
		const c = b - a;
		return y2 + n / 2 * (a + b + n * c);
	},
	julianDay(year, month, day, hours = 0) {
		const trunc = Math.trunc;
		const Y = trunc(month > 2 ? year : year - 1);
		const M = trunc(month > 2 ? month : month + 12);
		const D = day + hours / 24;
		const A = trunc(Y / 100);
		const B = trunc(2 - A + trunc(A / 4));
		return trunc(365.25 * (Y + 4716)) + trunc(30.6001 * (M + 1)) + D + B - 1524.5;
	},
	julianCentury(julianDay) {
		return (julianDay - 2451545) / 36525;
	},
	seasonAdjustedMorningTwilight(latitude, dayOfYear, year, sunrise) {
		const a = 75 + 28.65 / 55 * Math.abs(latitude);
		const b = 75 + 19.44 / 55 * Math.abs(latitude);
		const c = 75 + 32.74 / 55 * Math.abs(latitude);
		const d = 75 + 48.1 / 55 * Math.abs(latitude);
		const adjustment = function() {
			const dyy = Astronomical.daysSinceSolstice(dayOfYear, year, latitude);
			if (dyy < 91) return a + (b - a) / 91 * dyy;
			else if (dyy < 137) return b + (c - b) / 46 * (dyy - 91);
			else if (dyy < 183) return c + (d - c) / 46 * (dyy - 137);
			else if (dyy < 229) return d + (c - d) / 46 * (dyy - 183);
			else if (dyy < 275) return c + (b - c) / 46 * (dyy - 229);
			else return b + (a - b) / 91 * (dyy - 275);
		}();
		return dateByAddingSeconds(sunrise, Math.round(adjustment * -60));
	},
	seasonAdjustedEveningTwilight(latitude, dayOfYear, year, sunset, shafaq) {
		let a, b, c, d;
		if (shafaq === Shafaq.Ahmer) {
			a = 62 + 17.4 / 55 * Math.abs(latitude);
			b = 62 - 7.16 / 55 * Math.abs(latitude);
			c = 62 + 5.12 / 55 * Math.abs(latitude);
			d = 62 + 19.44 / 55 * Math.abs(latitude);
		} else if (shafaq === Shafaq.Abyad) {
			a = 75 + 25.6 / 55 * Math.abs(latitude);
			b = 75 + 7.16 / 55 * Math.abs(latitude);
			c = 75 + 36.84 / 55 * Math.abs(latitude);
			d = 75 + 81.84 / 55 * Math.abs(latitude);
		} else {
			a = 75 + 25.6 / 55 * Math.abs(latitude);
			b = 75 + 2.05 / 55 * Math.abs(latitude);
			c = 75 - 9.21 / 55 * Math.abs(latitude);
			d = 75 + 6.14 / 55 * Math.abs(latitude);
		}
		const adjustment = function() {
			const dyy = Astronomical.daysSinceSolstice(dayOfYear, year, latitude);
			if (dyy < 91) return a + (b - a) / 91 * dyy;
			else if (dyy < 137) return b + (c - b) / 46 * (dyy - 91);
			else if (dyy < 183) return c + (d - c) / 46 * (dyy - 137);
			else if (dyy < 229) return d + (c - d) / 46 * (dyy - 183);
			else if (dyy < 275) return c + (b - c) / 46 * (dyy - 229);
			else return b + (a - b) / 91 * (dyy - 275);
		}();
		return dateByAddingSeconds(sunset, Math.round(adjustment * 60));
	},
	daysSinceSolstice(dayOfYear, year, latitude) {
		let daysSinceSolstice;
		const northernOffset = 10;
		const southernOffset = isLeapYear(year) ? 173 : 172;
		const daysInYear = isLeapYear(year) ? 366 : 365;
		if (latitude >= 0) {
			daysSinceSolstice = dayOfYear + northernOffset;
			if (daysSinceSolstice >= daysInYear) daysSinceSolstice = daysSinceSolstice - daysInYear;
		} else {
			daysSinceSolstice = dayOfYear - southernOffset;
			if (daysSinceSolstice < 0) daysSinceSolstice = daysSinceSolstice + daysInYear;
		}
		return daysSinceSolstice;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/SolarCoordinates.js
var SolarCoordinates = class {
	constructor(julianDay) {
		const T = Astronomical.julianCentury(julianDay);
		const L0 = Astronomical.meanSolarLongitude(T);
		const Lp = Astronomical.meanLunarLongitude(T);
		const Omega = Astronomical.ascendingLunarNodeLongitude(T);
		const Lambda = degreesToRadians(Astronomical.apparentSolarLongitude(T, L0));
		const Theta0 = Astronomical.meanSiderealTime(T);
		const dPsi = Astronomical.nutationInLongitude(T, L0, Lp, Omega);
		const dEpsilon = Astronomical.nutationInObliquity(T, L0, Lp, Omega);
		const Epsilon0 = Astronomical.meanObliquityOfTheEcliptic(T);
		const EpsilonApparent = degreesToRadians(Astronomical.apparentObliquityOfTheEcliptic(T, Epsilon0));
		this.declination = radiansToDegrees(Math.asin(Math.sin(EpsilonApparent) * Math.sin(Lambda)));
		this.rightAscension = unwindAngle(radiansToDegrees(Math.atan2(Math.cos(EpsilonApparent) * Math.sin(Lambda), Math.cos(Lambda))));
		this.apparentSiderealTime = Theta0 + dPsi * 3600 * Math.cos(degreesToRadians(Epsilon0 + dEpsilon)) / 3600;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/SolarTime.js
var SolarTime = class {
	constructor(date, coordinates) {
		const julianDay = Astronomical.julianDay(date.getFullYear(), date.getMonth() + 1, date.getDate(), 0);
		this.observer = coordinates;
		this.solar = new SolarCoordinates(julianDay);
		this.prevSolar = new SolarCoordinates(julianDay - 1);
		this.nextSolar = new SolarCoordinates(julianDay + 1);
		const m0 = Astronomical.approximateTransit(coordinates.longitude, this.solar.apparentSiderealTime, this.solar.rightAscension);
		const solarAltitude = -50 / 60;
		this.approxTransit = m0;
		this.transit = Astronomical.correctedTransit(m0, coordinates.longitude, this.solar.apparentSiderealTime, this.solar.rightAscension, this.prevSolar.rightAscension, this.nextSolar.rightAscension);
		this.sunrise = Astronomical.correctedHourAngle(m0, solarAltitude, coordinates, false, this.solar.apparentSiderealTime, this.solar.rightAscension, this.prevSolar.rightAscension, this.nextSolar.rightAscension, this.solar.declination, this.prevSolar.declination, this.nextSolar.declination);
		this.sunset = Astronomical.correctedHourAngle(m0, solarAltitude, coordinates, true, this.solar.apparentSiderealTime, this.solar.rightAscension, this.prevSolar.rightAscension, this.nextSolar.rightAscension, this.solar.declination, this.prevSolar.declination, this.nextSolar.declination);
	}
	hourAngle(angle, afterTransit) {
		return Astronomical.correctedHourAngle(this.approxTransit, angle, this.observer, afterTransit, this.solar.apparentSiderealTime, this.solar.rightAscension, this.prevSolar.rightAscension, this.nextSolar.rightAscension, this.solar.declination, this.prevSolar.declination, this.nextSolar.declination);
	}
	afternoon(shadowLength) {
		const tangent = Math.abs(this.observer.latitude - this.solar.declination);
		const inverse = shadowLength + Math.tan(degreesToRadians(tangent));
		const angle = radiansToDegrees(Math.atan(1 / inverse));
		return this.hourAngle(angle, true);
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/PolarCircleResolution.js
var PolarCircleResolution = {
	AqrabBalad: "AqrabBalad",
	AqrabYaum: "AqrabYaum",
	Unresolved: "Unresolved"
};
var LATITUDE_VARIATION_STEP = .5;
var UNSAFE_LATITUDE = 65;
var isValidSolarTime = (solarTime) => !isNaN(solarTime.sunrise) && !isNaN(solarTime.sunset);
var aqrabYaumResolver = (coordinates, date, daysAdded = 1, direction = 1) => {
	if (daysAdded > Math.ceil(365 / 2)) return null;
	const testDate = new Date(date.getTime());
	testDate.setDate(testDate.getDate() + direction * daysAdded);
	const tomorrow = dateByAddingDays(testDate, 1);
	const solarTime = new SolarTime(testDate, coordinates);
	const tomorrowSolarTime = new SolarTime(tomorrow, coordinates);
	if (!isValidSolarTime(solarTime) || !isValidSolarTime(tomorrowSolarTime)) return aqrabYaumResolver(coordinates, date, daysAdded + (direction > 0 ? 0 : 1), -direction);
	return {
		date,
		tomorrow,
		coordinates,
		solarTime,
		tomorrowSolarTime
	};
};
var aqrabBaladResolver = (coordinates, date, latitude) => {
	const solarTime = new SolarTime(date, {
		...coordinates,
		latitude
	});
	const tomorrow = dateByAddingDays(date, 1);
	const tomorrowSolarTime = new SolarTime(tomorrow, {
		...coordinates,
		latitude
	});
	if (!isValidSolarTime(solarTime) || !isValidSolarTime(tomorrowSolarTime)) return Math.abs(latitude) >= UNSAFE_LATITUDE ? aqrabBaladResolver(coordinates, date, latitude - Math.sign(latitude) * LATITUDE_VARIATION_STEP) : null;
	return {
		date,
		tomorrow,
		coordinates: new Coordinates(latitude, coordinates.longitude),
		solarTime,
		tomorrowSolarTime
	};
};
var polarCircleResolvedValues = (resolver, date, coordinates) => {
	const defaultReturn = {
		date,
		tomorrow: dateByAddingDays(date, 1),
		coordinates,
		solarTime: new SolarTime(date, coordinates),
		tomorrowSolarTime: new SolarTime(dateByAddingDays(date, 1), coordinates)
	};
	switch (resolver) {
		case PolarCircleResolution.AqrabYaum: return aqrabYaumResolver(coordinates, date) || defaultReturn;
		case PolarCircleResolution.AqrabBalad: {
			const { latitude } = coordinates;
			return aqrabBaladResolver(coordinates, date, latitude - Math.sign(latitude) * LATITUDE_VARIATION_STEP) || defaultReturn;
		}
		default: return defaultReturn;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/CalculationParameters.js
var CalculationParameters = class {
	madhab = Madhab.Shafi;
	highLatitudeRule = HighLatitudeRule.MiddleOfTheNight;
	adjustments = {
		fajr: 0,
		sunrise: 0,
		dhuhr: 0,
		asr: 0,
		maghrib: 0,
		isha: 0
	};
	methodAdjustments = {
		fajr: 0,
		sunrise: 0,
		dhuhr: 0,
		asr: 0,
		maghrib: 0,
		isha: 0
	};
	polarCircleResolution = PolarCircleResolution.Unresolved;
	rounding = Rounding.Nearest;
	shafaq = Shafaq.General;
	constructor(method, fajrAngle = 0, ishaAngle = 0, ishaInterval = 0, maghribAngle = 0) {
		this.method = method;
		this.fajrAngle = fajrAngle;
		this.ishaAngle = ishaAngle;
		this.ishaInterval = ishaInterval;
		this.maghribAngle = maghribAngle;
		if (this.method === null) this.method = "Other";
	}
	nightPortions() {
		switch (this.highLatitudeRule) {
			case HighLatitudeRule.MiddleOfTheNight: return {
				fajr: 1 / 2,
				isha: 1 / 2
			};
			case HighLatitudeRule.SeventhOfTheNight: return {
				fajr: 1 / 7,
				isha: 1 / 7
			};
			case HighLatitudeRule.TwilightAngle: return {
				fajr: this.fajrAngle / 60,
				isha: this.ishaAngle / 60
			};
			default: throw `Invalid high latitude rule found when attempting to compute night portions: ${this.highLatitudeRule}`;
		}
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/CalculationMethod.js
var CalculationMethod = {
	MuslimWorldLeague() {
		const params = new CalculationParameters("MuslimWorldLeague", 18, 17);
		params.methodAdjustments.dhuhr = 1;
		return params;
	},
	Egyptian() {
		const params = new CalculationParameters("Egyptian", 19.5, 17.5);
		params.methodAdjustments.dhuhr = 1;
		return params;
	},
	Karachi() {
		const params = new CalculationParameters("Karachi", 18, 18);
		params.methodAdjustments.dhuhr = 1;
		return params;
	},
	UmmAlQura() {
		return new CalculationParameters("UmmAlQura", 18.5, 0, 90);
	},
	Dubai() {
		const params = new CalculationParameters("Dubai", 18.2, 18.2);
		params.methodAdjustments = {
			...params.methodAdjustments,
			sunrise: -3,
			dhuhr: 3,
			asr: 3,
			maghrib: 3
		};
		return params;
	},
	MoonsightingCommittee() {
		const params = new CalculationParameters("MoonsightingCommittee", 18, 18);
		params.methodAdjustments = {
			...params.methodAdjustments,
			dhuhr: 5,
			maghrib: 3
		};
		return params;
	},
	NorthAmerica() {
		const params = new CalculationParameters("NorthAmerica", 15, 15);
		params.methodAdjustments.dhuhr = 1;
		return params;
	},
	Kuwait() {
		return new CalculationParameters("Kuwait", 18, 17.5);
	},
	Qatar() {
		return new CalculationParameters("Qatar", 18, 0, 90);
	},
	Singapore() {
		const params = new CalculationParameters("Singapore", 20, 18);
		params.methodAdjustments.dhuhr = 1;
		params.rounding = Rounding.Up;
		return params;
	},
	Tehran() {
		return new CalculationParameters("Tehran", 17.7, 14, 0, 4.5);
	},
	Turkey() {
		const params = new CalculationParameters("Turkey", 18, 17);
		params.methodAdjustments = {
			...params.methodAdjustments,
			sunrise: -7,
			dhuhr: 5,
			asr: 4,
			maghrib: 7
		};
		return params;
	},
	Other() {
		return new CalculationParameters("Other", 0, 0);
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/Prayer.js
var Prayer = {
	Fajr: "fajr",
	Sunrise: "sunrise",
	Dhuhr: "dhuhr",
	Asr: "asr",
	Maghrib: "maghrib",
	Isha: "isha",
	None: "none"
};
//#endregion
//#region node_modules/adhan/lib/esm/TimeComponents.js
var TimeComponents = class {
	constructor(num) {
		this.hours = Math.floor(num);
		this.minutes = Math.floor((num - this.hours) * 60);
		this.seconds = Math.floor((num - (this.hours + this.minutes / 60)) * 60 * 60);
		return this;
	}
	utcDate(year, month, date) {
		return new Date(Date.UTC(year, month, date, this.hours, this.minutes, this.seconds));
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/PrayerTimes.js
var HIGH_LATITUDE_THRESHOLD = 55;
var PrayerTimes = class {
	constructor(coordinates, date, calculationParameters) {
		this.coordinates = coordinates;
		this.date = date;
		this.calculationParameters = calculationParameters;
		let solarTime = new SolarTime(date, coordinates);
		let fajrTime;
		let sunriseTime;
		let dhuhrTime;
		let asrTime;
		let sunsetTime;
		let maghribTime;
		let ishaTime;
		let nightFraction;
		dhuhrTime = new TimeComponents(solarTime.transit).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
		sunriseTime = new TimeComponents(solarTime.sunrise).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
		sunsetTime = new TimeComponents(solarTime.sunset).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
		const tomorrow = dateByAddingDays(date, 1);
		let tomorrowSolarTime = new SolarTime(tomorrow, coordinates);
		const polarCircleResolver = calculationParameters.polarCircleResolution;
		if ((!isValidDate(sunriseTime) || !isValidDate(sunsetTime) || isNaN(tomorrowSolarTime.sunrise)) && polarCircleResolver !== PolarCircleResolution.Unresolved) {
			const resolved = polarCircleResolvedValues(polarCircleResolver, date, coordinates);
			solarTime = resolved.solarTime;
			tomorrowSolarTime = resolved.tomorrowSolarTime;
			const dateComponents = [
				date.getFullYear(),
				date.getMonth(),
				date.getDate()
			];
			dhuhrTime = new TimeComponents(solarTime.transit).utcDate(...dateComponents);
			sunriseTime = new TimeComponents(solarTime.sunrise).utcDate(...dateComponents);
			sunsetTime = new TimeComponents(solarTime.sunset).utcDate(...dateComponents);
		}
		asrTime = new TimeComponents(solarTime.afternoon(shadowLength(calculationParameters.madhab))).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
		const tomorrowSunrise = new TimeComponents(tomorrowSolarTime.sunrise).utcDate(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate());
		const night = (Number(tomorrowSunrise) - Number(sunsetTime)) / 1e3;
		fajrTime = new TimeComponents(solarTime.hourAngle(-1 * calculationParameters.fajrAngle, false)).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
		if (calculationParameters.method === "MoonsightingCommittee" && coordinates.latitude >= HIGH_LATITUDE_THRESHOLD) {
			nightFraction = night / 7;
			fajrTime = dateByAddingSeconds(sunriseTime, -nightFraction);
		}
		const safeFajr = function() {
			if (calculationParameters.method === "MoonsightingCommittee") return Astronomical.seasonAdjustedMorningTwilight(coordinates.latitude, dayOfYear(date), date.getFullYear(), sunriseTime);
			else {
				nightFraction = calculationParameters.nightPortions().fajr * night;
				return dateByAddingSeconds(sunriseTime, -nightFraction);
			}
		}();
		if (isNaN(fajrTime.getTime()) || safeFajr > fajrTime) fajrTime = safeFajr;
		if (calculationParameters.ishaInterval > 0) ishaTime = dateByAddingMinutes(sunsetTime, calculationParameters.ishaInterval);
		else {
			ishaTime = new TimeComponents(solarTime.hourAngle(-1 * calculationParameters.ishaAngle, true)).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
			if (calculationParameters.method === "MoonsightingCommittee" && coordinates.latitude >= HIGH_LATITUDE_THRESHOLD) {
				nightFraction = night / 7;
				ishaTime = dateByAddingSeconds(sunsetTime, nightFraction);
			}
			const safeIsha = function() {
				if (calculationParameters.method === "MoonsightingCommittee") return Astronomical.seasonAdjustedEveningTwilight(coordinates.latitude, dayOfYear(date), date.getFullYear(), sunsetTime, calculationParameters.shafaq);
				else {
					nightFraction = calculationParameters.nightPortions().isha * night;
					return dateByAddingSeconds(sunsetTime, nightFraction);
				}
			}();
			if (isNaN(ishaTime.getTime()) || safeIsha < ishaTime) ishaTime = safeIsha;
		}
		maghribTime = sunsetTime;
		if (calculationParameters.maghribAngle) {
			const angleBasedMaghrib = new TimeComponents(solarTime.hourAngle(-1 * calculationParameters.maghribAngle, true)).utcDate(date.getFullYear(), date.getMonth(), date.getDate());
			if (sunsetTime < angleBasedMaghrib && ishaTime > angleBasedMaghrib) maghribTime = angleBasedMaghrib;
		}
		const fajrAdjustment = (calculationParameters.adjustments.fajr || 0) + (calculationParameters.methodAdjustments.fajr || 0);
		const sunriseAdjustment = (calculationParameters.adjustments.sunrise || 0) + (calculationParameters.methodAdjustments.sunrise || 0);
		const dhuhrAdjustment = (calculationParameters.adjustments.dhuhr || 0) + (calculationParameters.methodAdjustments.dhuhr || 0);
		const asrAdjustment = (calculationParameters.adjustments.asr || 0) + (calculationParameters.methodAdjustments.asr || 0);
		const maghribAdjustment = (calculationParameters.adjustments.maghrib || 0) + (calculationParameters.methodAdjustments.maghrib || 0);
		const ishaAdjustment = (calculationParameters.adjustments.isha || 0) + (calculationParameters.methodAdjustments.isha || 0);
		this.fajr = roundedMinute(dateByAddingMinutes(fajrTime, fajrAdjustment), calculationParameters.rounding);
		this.sunrise = roundedMinute(dateByAddingMinutes(sunriseTime, sunriseAdjustment), calculationParameters.rounding);
		this.dhuhr = roundedMinute(dateByAddingMinutes(dhuhrTime, dhuhrAdjustment), calculationParameters.rounding);
		this.asr = roundedMinute(dateByAddingMinutes(asrTime, asrAdjustment), calculationParameters.rounding);
		this.sunset = roundedMinute(sunsetTime, calculationParameters.rounding);
		this.maghrib = roundedMinute(dateByAddingMinutes(maghribTime, maghribAdjustment), calculationParameters.rounding);
		this.isha = roundedMinute(dateByAddingMinutes(ishaTime, ishaAdjustment), calculationParameters.rounding);
	}
	timeForPrayer(prayer) {
		if (prayer === Prayer.Fajr) return this.fajr;
		else if (prayer === Prayer.Sunrise) return this.sunrise;
		else if (prayer === Prayer.Dhuhr) return this.dhuhr;
		else if (prayer === Prayer.Asr) return this.asr;
		else if (prayer === Prayer.Maghrib) return this.maghrib;
		else if (prayer === Prayer.Isha) return this.isha;
		else return null;
	}
	currentPrayer(date = /* @__PURE__ */ new Date()) {
		if (date >= this.isha) return Prayer.Isha;
		else if (date >= this.maghrib) return Prayer.Maghrib;
		else if (date >= this.asr) return Prayer.Asr;
		else if (date >= this.dhuhr) return Prayer.Dhuhr;
		else if (date >= this.sunrise) return Prayer.Sunrise;
		else if (date >= this.fajr) return Prayer.Fajr;
		else return Prayer.None;
	}
	nextPrayer(date = /* @__PURE__ */ new Date()) {
		if (date >= this.isha) return Prayer.None;
		else if (date >= this.maghrib) return Prayer.Isha;
		else if (date >= this.asr) return Prayer.Maghrib;
		else if (date >= this.dhuhr) return Prayer.Asr;
		else if (date >= this.sunrise) return Prayer.Dhuhr;
		else if (date >= this.fajr) return Prayer.Sunrise;
		else return Prayer.Fajr;
	}
};
//#endregion
//#region node_modules/adhan/lib/esm/Qibla.js
function qibla(coordinates) {
	const makkah = new Coordinates(21.4225241, 39.8261818);
	const term1 = Math.sin(degreesToRadians(makkah.longitude) - degreesToRadians(coordinates.longitude));
	const term2 = Math.cos(degreesToRadians(coordinates.latitude)) * Math.tan(degreesToRadians(makkah.latitude));
	const term3 = Math.sin(degreesToRadians(coordinates.latitude)) * Math.cos(degreesToRadians(makkah.longitude) - degreesToRadians(coordinates.longitude));
	return unwindAngle(radiansToDegrees(Math.atan2(term1, term2 - term3)));
}
//#endregion
export { Madhab as a, Coordinates as i, PrayerTimes as n, CalculationMethod as r, qibla as t };
