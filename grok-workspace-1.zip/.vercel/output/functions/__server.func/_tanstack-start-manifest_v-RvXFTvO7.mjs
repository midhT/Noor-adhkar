//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RvXFTvO7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BsxT3VUb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BsxT3VUb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cw3cQZT8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
