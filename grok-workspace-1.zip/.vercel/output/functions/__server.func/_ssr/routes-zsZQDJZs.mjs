import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pencil, c as LocateFixed, d as ChevronRight, f as ChevronLeft, h as Bell, i as RefreshCw, l as LayoutGrid, m as BookMarked, o as MoonStar, p as BookOpen, r as SlidersHorizontal, s as MapPin, t as WifiOff, u as Fingerprint } from "../_libs/lucide-react.mjs";
import { a as Madhab, i as Coordinates, n as PrayerTimes, r as CalculationMethod, t as qibla } from "../_libs/adhan.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-zsZQDJZs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var verses = [
	{
		arabic: "وَمَا الْحَيَاةُ الدُّنْيَا إِلَّا مَتَاعُ الْغُرُورِ",
		translation: "The life of this world is only the enjoyment of delusion.",
		reference: "Quran 3:185"
	},
	{
		arabic: "وَاللَّهُ خَيْرُ الْمَاكِرِينَ",
		translation: "And Allah is the best of planners.",
		reference: "Quran 3:54"
	},
	{
		arabic: "وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ",
		translation: "My success is only through Allah.",
		reference: "Quran 11:88"
	},
	{
		arabic: "لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا",
		translation: "Do not grieve; indeed Allah is with us.",
		reference: "Quran 9:40"
	},
	{
		arabic: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا",
		translation: "For indeed, with hardship comes ease.",
		reference: "Quran 94:5"
	},
	{
		arabic: "إِنَّ مَعَ الْعُسْرِ يُسْرًا",
		translation: "Indeed, with hardship comes ease.",
		reference: "Quran 94:6"
	},
	{
		arabic: "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
		translation: "Allah does not burden a soul beyond what it can bear.",
		reference: "Quran 2:286"
	},
	{
		arabic: "وَهُوَ مَعَكُمْ أَيْنَ مَا كُنْتُمْ",
		translation: "He is with you wherever you are.",
		reference: "Quran 57:4"
	},
	{
		arabic: "أَلَيْسَ اللَّهُ بِكَافٍ عَبْدَهُ",
		translation: "Is Allah not sufficient for His servant?",
		reference: "Quran 39:36"
	},
	{
		arabic: "وَلَا تَيْأَسُوا مِنْ رَوْحِ اللَّهِ",
		translation: "Do not despair of relief from Allah.",
		reference: "Quran 12:87"
	},
	{
		arabic: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
		translation: "Indeed, Allah is with the patient.",
		reference: "Quran 2:153"
	},
	{
		arabic: "فَاذْكُرُونِي أَذْكُرْكُمْ",
		translation: "So remember Me; I will remember you.",
		reference: "Quran 2:152"
	},
	{
		arabic: "وَقُلْ رَبِّ زِدْنِي عِلْمًا",
		translation: "And say: My Lord, increase me in knowledge.",
		reference: "Quran 20:114"
	},
	{
		arabic: "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
		translation: "Allah is sufficient for us, and He is the best disposer of affairs.",
		reference: "Quran 3:173"
	},
	{
		arabic: "إِنَّ اللَّهَ يُحِبُّ الْمُتَوَكِّلِينَ",
		translation: "Indeed, Allah loves those who rely upon Him.",
		reference: "Quran 3:159"
	}
];
function verseOfDay(date) {
	return verses[date.getDate() % verses.length] ?? verses[0];
}
var duas = [
	{
		arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
		translation: "Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
		reference: "Al-Baqarah 2:201"
	},
	{
		arabic: "رَبِّ زِدْنِي عِلْمًا",
		translation: "My Lord, increase me in knowledge.",
		reference: "Ta-Ha 20:114"
	},
	{
		arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ",
		translation: "O Allah, I ask You for pardon and well-being.",
		reference: "Prophetic supplication; verify wording with a trusted source"
	},
	{
		arabic: "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ",
		translation: "Our Lord, do not let our hearts deviate after You have guided us, and grant us mercy from Yourself. Indeed, You are the Bestower.",
		reference: "Ali Imran 3:8"
	},
	{
		arabic: "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
		translation: "My Lord, expand for me my chest and ease my task for me.",
		reference: "Ta-Ha 20:25–26"
	},
	{
		arabic: "رَبَّنَا تَقَبَّلْ مِنَّا ۖ إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ",
		translation: "Our Lord, accept from us. Indeed, You are the Hearing, the Knowing.",
		reference: "Al-Baqarah 2:127"
	}
];
var dhikrPresets = [
	"سُبْحَانَ اللَّهِ",
	"الْحَمْدُ لِلَّهِ",
	"اللَّهُ أَكْبَرُ",
	"لَا إِلَٰهَ إِلَّا اللَّهُ",
	"أَسْتَغْفِرُ اللَّهَ"
];
var DEFAULT_DHIKR = dhikrPresets[0];
var cities = [
	{
		name: "Srinagar",
		lat: 34.0837,
		lon: 74.7973
	},
	{
		name: "Delhi",
		lat: 28.6139,
		lon: 77.209
	},
	{
		name: "Makkah",
		lat: 21.4225,
		lon: 39.8262
	},
	{
		name: "Madinah",
		lat: 24.4672,
		lon: 39.6111
	},
	{
		name: "Karachi",
		lat: 24.8607,
		lon: 67.0011
	},
	{
		name: "London",
		lat: 51.5072,
		lon: -.1276
	}
];
function Sheet({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 sm:items-center",
		onClick: onClose,
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "w-full max-w-md rounded-t-3xl border border-line bg-surface p-5 sm:rounded-3xl",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium",
				children: title
			}), children]
		})
	});
}
function Field({ label, value, onChange, placeholder, inputMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-3 block text-sm text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			inputMode,
			placeholder,
			onChange: (event) => onChange(event.target.value),
			className: "mt-1 h-12 w-full rounded-2xl bg-surface-2 px-4 text-base text-fg outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg"
		})]
	});
}
function TextButton({ children, onClick, tone = "ghost" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `inline-flex h-11 items-center justify-center rounded-2xl px-4 text-sm font-medium ${tone === "solid" ? "bg-fg text-bg" : "border border-line bg-transparent text-fg"}`,
		children
	});
}
function Arabic({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		lang: "ar",
		dir: "rtl",
		className: `font-arabic text-center leading-relaxed text-balance ${className}`,
		children
	});
}
var GOAL = 33;
function DhikrScreen({ count, dhikr, onCount, onDhikr }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(dhikr);
	const progress = count % GOAL / GOAL;
	const radius = 102;
	const circ = 2 * Math.PI * radius;
	const rounds = Math.floor(count / GOAL);
	function tap() {
		onCount(count + 1);
		if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate(12);
	}
	function save() {
		const next = draft.trim();
		if (!next) return;
		onDhikr(next);
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium",
				children: "Dhikr"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "A moment of remembrance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arabic, {
				className: "mt-8 text-3xl",
				children: dhikr
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-7xl font-light tabular-nums",
				"aria-live": "polite",
				children: count
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs tracking-widest text-muted",
				children: "COUNT"
			}),
			rounds > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-center text-xs text-muted",
				children: [
					rounds,
					" ",
					rounds === 1 ? "round" : "rounds",
					" of ",
					GOAL
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-center text-xs text-muted",
				children: [GOAL, " to a round"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: tap,
					"aria-label": "Count dhikr",
					className: "relative grid size-64 place-items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 220 220",
						className: "size-64",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "110",
							cy: "110",
							r: radius,
							className: "fill-none stroke-line",
							strokeWidth: "2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "110",
							cy: "110",
							r: radius,
							className: "fill-none stroke-fg",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeDasharray: `${circ * progress} ${circ}`,
							transform: "rotate(-90 110 110)"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "dhikr-shadow absolute grid size-44 place-items-center rounded-full border border-line bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tracking-widest text-muted",
							children: "TAP"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex gap-2 overflow-x-auto pb-1",
				children: dhikrPresets.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onDhikr(preset),
					className: `h-11 shrink-0 rounded-full border px-4 font-arabic text-lg ${dhikr === preset ? "border-fg bg-ink" : "border-line text-muted"}`,
					children: preset
				}, preset))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setDraft(dhikr);
						setOpen(true);
					},
					className: "h-11 rounded-2xl border border-line text-sm font-medium",
					children: "Change dhikr"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onCount(0),
					className: "h-11 rounded-2xl border border-line text-sm font-medium",
					children: "Reset"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open,
				title: "Custom dhikr",
				onClose: () => setOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phrase",
					value: draft,
					onChange: setDraft
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
						onClick: () => setOpen(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
						tone: "solid",
						onClick: save,
						children: "Save"
					})]
				})]
			})
		]
	});
}
function DuasScreen({ onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onBack,
				className: "inline-flex h-11 items-center gap-1 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Settings"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 text-3xl font-medium",
				children: "Duas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Supplications to keep close"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 flex flex-col gap-3",
				children: duas.map((dua) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-3xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arabic, {
							className: "text-2xl",
							children: dua.arabic
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-sm leading-relaxed text-pretty",
							children: dua.translation
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-xs text-muted",
							children: dua.reference
						})
					]
				}, dua.reference + dua.arabic))
			})
		]
	});
}
var METHODS = [
	{
		id: "Karachi",
		label: "Karachi"
	},
	{
		id: "MuslimWorldLeague",
		label: "Muslim World League"
	},
	{
		id: "Egyptian",
		label: "Egyptian"
	},
	{
		id: "UmmAlQura",
		label: "Umm al-Qura"
	},
	{
		id: "NorthAmerica",
		label: "North America"
	}
];
var builders = {
	Karachi: () => CalculationMethod.Karachi(),
	MuslimWorldLeague: () => CalculationMethod.MuslimWorldLeague(),
	Egyptian: () => CalculationMethod.Egyptian(),
	UmmAlQura: () => CalculationMethod.UmmAlQura(),
	NorthAmerica: () => CalculationMethod.NorthAmerica()
};
function methodLabel(id) {
	return METHODS.find((m) => m.id === id)?.label ?? id;
}
function daySchedule(latitude, longitude, method, asr, date) {
	const params = builders[method]();
	params.madhab = asr === "Shafi" ? Madhab.Shafi : Madhab.Hanafi;
	const times = new PrayerTimes(new Coordinates(latitude, longitude), date, params);
	const slots = [
		{
			name: "Fajr",
			at: times.fajr
		},
		{
			name: "Sunrise",
			at: times.sunrise
		},
		{
			name: "Dhuhr",
			at: times.dhuhr
		},
		{
			name: "Asr",
			at: times.asr
		},
		{
			name: "Maghrib",
			at: times.maghrib
		},
		{
			name: "Isha",
			at: times.isha
		}
	];
	if (slots.some((s) => Number.isNaN(s.at.getTime()))) throw new Error("Prayer times could not be calculated for this location.");
	return slots;
}
function shiftDay(date, days) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, 12, 0, 0, 0);
}
function agenda(latitude, longitude, method, asr, now) {
	const today = daySchedule(latitude, longitude, method, asr, now);
	const span = [
		...daySchedule(latitude, longitude, method, asr, shiftDay(now, -1)),
		...today,
		...daySchedule(latitude, longitude, method, asr, shiftDay(now, 1))
	].sort((a, b) => a.at.getTime() - b.at.getTime());
	const future = span.filter((s) => s.at.getTime() > now.getTime());
	const nextSalah = future.find((s) => s.name !== "Sunrise") ?? span[span.length - 1];
	const nextIndex = span.findIndex((s) => s.at.getTime() === nextSalah.at.getTime() && s.name === nextSalah.name);
	const previous = span[Math.max(0, nextIndex - 1)] ?? nextSalah;
	return {
		today,
		nextSalah,
		sunriseBefore: future.find((s) => s.name === "Sunrise" && s.at.getTime() < nextSalah.at.getTime()) ?? null,
		previous,
		qibla: qibla(new Coordinates(latitude, longitude))
	};
}
function formatClock(date) {
	return new Intl.DateTimeFormat("en-US", {
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
function formatRemaining(ms) {
	const total = Math.floor(Math.max(0, ms) / 1e3);
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}h ${m}m`;
	if (m > 0) return `${m}m ${String(s).padStart(2, "0")}s`;
	return `${s}s`;
}
function formatCivil(date) {
	return new Intl.DateTimeFormat("en-GB", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(date);
}
function formatHijri(date) {
	try {
		return new Intl.DateTimeFormat("en-GB-u-ca-islamic", {
			day: "numeric",
			month: "long",
			year: "numeric"
		}).format(date);
	} catch {
		return "";
	}
}
var COMPASS = [
	"N",
	"NE",
	"E",
	"SE",
	"S",
	"SW",
	"W",
	"NW"
];
function compassPoint(degrees) {
	const norm = (degrees % 360 + 360) % 360;
	return COMPASS[Math.round(norm / 45) % 8] ?? "N";
}
function parseClock(value) {
	if (!value) return null;
	const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
	if (!match) return null;
	const hour = Number(match[1]);
	const minute = Number(match[2]);
	if (!Number.isInteger(hour) || !Number.isInteger(minute)) return null;
	if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
	return {
		hour,
		minute
	};
}
function jamaatOn(date, value) {
	const parsed = parseClock(value);
	if (!parsed) return null;
	return new Date(date.getFullYear(), date.getMonth(), date.getDate(), parsed.hour, parsed.minute, 0, 0);
}
function HomeScreen({ now, latitude, longitude, place, method, asr, count, onRefresh, onOpenSalah, onOpenDhikr, onOpenQuran }) {
	const verse = verseOfDay(now);
	let nextName = "Location needed";
	let nextTime = "--:--";
	let remain = "";
	let sunrise = "";
	let progress = 0;
	let error = "";
	if (latitude != null && longitude != null) try {
		const plan = agenda(latitude, longitude, method, asr, now);
		nextName = plan.nextSalah.name;
		nextTime = formatClock(plan.nextSalah.at);
		remain = formatRemaining(plan.nextSalah.at.getTime() - now.getTime());
		const span = plan.nextSalah.at.getTime() - plan.previous.at.getTime();
		const done = now.getTime() - plan.previous.at.getTime();
		progress = span > 0 ? Math.min(100, Math.max(0, done / span * 100)) : 0;
		if (plan.sunriseBefore) sunrise = `Sunrise ${formatClock(plan.sunriseBefore.at)}`;
	} catch (caught) {
		error = caught instanceof Error ? caught.message : "Prayer times could not be calculated.";
		nextName = "Unavailable";
	}
	const hijri = formatHijri(now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-11 place-items-center rounded-2xl border border-line font-arabic text-2xl",
						children: "ن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold tracking-widest",
							children: "NOOR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "A quieter daily rhythm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onRefresh,
						"aria-label": "Refresh",
						className: "ml-auto grid size-11 place-items-center rounded-2xl text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-muted",
				children: formatCivil(now)
			}),
			hijri ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hijri
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-medium text-balance",
				children: "Assalamu Alaikum"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 rounded-3xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, { className: "size-4" }), place]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs tracking-widest text-muted",
						children: "UP NEXT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-4xl font-light",
							children: nextName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pb-1 text-xl text-muted tabular-nums",
							children: nextTime
						})]
					}),
					remain ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted tabular-nums",
						children: ["in ", remain]
					}) : null,
					sunrise ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: sunrise
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: error
					}) : null,
					latitude != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-1 overflow-hidden rounded-full bg-ink",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-fg",
							style: { width: `${progress}%` }
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onOpenSalah,
						className: "mt-5 h-11 w-full rounded-2xl border border-line text-sm font-medium tracking-wide",
						children: "View prayer times"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenDhikr,
					className: "rounded-3xl border border-line bg-surface p-4 text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-3xl font-light tabular-nums",
							children: count
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs tracking-widest text-muted",
							children: "DHIKR TODAY"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenQuran,
					className: "rounded-3xl border border-line bg-surface p-4 text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-3xl font-light",
							children: "Read"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs tracking-widest text-muted",
							children: "DAILY VERSE"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-7 text-xs tracking-widest text-muted",
				children: "A VERSE TO CARRY"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arabic, {
						className: "text-3xl",
						children: verse.arabic
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-sm leading-relaxed text-pretty",
						children: verse.translation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xs text-muted",
						children: verse.reference
					})
				]
			})
		]
	});
}
function QuranScreen() {
	const [query, setQuery] = (0, import_react.useState)("");
	const needle = query.trim().toLowerCase();
	const shown = (0, import_react.useMemo)(() => needle ? verses.filter((verse) => `${verse.arabic} ${verse.translation} ${verse.reference}`.toLowerCase().includes(needle)) : verses, [needle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium",
				children: "Quran"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "A collection of verses for reflection"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Search verses",
				"aria-label": "Search verses",
				className: "mt-5 h-12 w-full rounded-2xl border border-line bg-surface-2 px-4 text-base outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg"
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "Nothing matches that."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-3",
				children: shown.map((verse) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-3xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arabic, {
							className: "text-2xl",
							children: verse.arabic
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-sm leading-relaxed text-pretty",
							children: verse.translation
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-xs text-muted",
							children: verse.reference
						})
					]
				}, verse.reference + verse.arabic))
			})
		]
	});
}
function SalahScreen({ now, latitude, longitude, place, method, asr, jamaat, onPlace, onJamaat }) {
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [coordsOpen, setCoordsOpen] = (0, import_react.useState)(false);
	const [latDraft, setLatDraft] = (0, import_react.useState)("");
	const [lonDraft, setLonDraft] = (0, import_react.useState)("");
	const [jamaatPrayer, setJamaatPrayer] = (0, import_react.useState)(null);
	const [jamaatDraft, setJamaatDraft] = (0, import_react.useState)("");
	const [jamaatError, setJamaatError] = (0, import_react.useState)("");
	let slots = [];
	let nextName = "";
	let qibla = "";
	let calcError = "";
	if (latitude != null && longitude != null) try {
		const plan = agenda(latitude, longitude, method, asr, now);
		slots = plan.today;
		nextName = plan.nextSalah.name;
		qibla = `Qibla ${Math.round((plan.qibla % 360 + 360) % 360)}° ${compassPoint(plan.qibla)}`;
	} catch (caught) {
		calcError = caught instanceof Error ? caught.message : "Prayer times could not be calculated.";
	}
	async function useLocation() {
		setBusy(true);
		setError("");
		try {
			if (!navigator.geolocation) throw new Error("Location is not available in this browser. Enter coordinates manually.");
			const position = await new Promise((resolve, reject) => {
				navigator.geolocation.getCurrentPosition(resolve, (err) => {
					if (err.code === err.PERMISSION_DENIED) {
						reject(/* @__PURE__ */ new Error("Location permission not granted. Enter coordinates manually."));
						return;
					}
					reject(/* @__PURE__ */ new Error("Location services are unavailable. Enter coordinates manually."));
				}, {
					enableHighAccuracy: true,
					timeout: 12e3,
					maximumAge: 6e4
				});
			});
			onPlace(position.coords.latitude, position.coords.longitude, "This device");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Location could not be read.");
		} finally {
			setBusy(false);
		}
	}
	function openCoords() {
		setLatDraft(latitude == null ? "" : String(latitude));
		setLonDraft(longitude == null ? "" : String(longitude));
		setCoordsOpen(true);
		setError("");
	}
	function saveCoords() {
		const latText = latDraft.trim();
		const lonText = lonDraft.trim();
		const lat = Number(latText);
		const lon = Number(lonText);
		if (!latText || !lonText || !Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
			setError("Please enter valid latitude and longitude.");
			return;
		}
		onPlace(lat, lon, "Saved coordinates");
		setError("");
		setCoordsOpen(false);
	}
	function openJamaat(prayer) {
		setJamaatPrayer(prayer);
		setJamaatDraft(jamaat[prayer] ?? "");
		setJamaatError("");
	}
	function saveJamaat() {
		if (!jamaatPrayer) return;
		const trimmed = jamaatDraft.trim();
		if (trimmed && !parseClock(trimmed)) {
			setJamaatError("Use 24-hour time, like 13:30.");
			return;
		}
		onJamaat(jamaatPrayer, trimmed);
		setJamaatPrayer(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium",
				children: "Salah"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Prayer times and your local Jamaat schedule"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void useLocation(),
					disabled: busy,
					className: "inline-flex h-11 items-center justify-center gap-2 rounded-2xl border border-line text-sm font-medium disabled:opacity-60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), busy ? "Locating" : "Location"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: openCoords,
					className: "inline-flex h-11 items-center justify-center gap-2 rounded-2xl border border-line text-sm font-medium",
					children: "Coordinates"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-2 overflow-x-auto pb-1",
				children: cities.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						onPlace(city.lat, city.lon, city.name);
						setError("");
					},
					className: `h-11 shrink-0 rounded-full border px-4 text-sm ${place === city.name ? "border-fg bg-ink text-fg" : "border-line text-muted"}`,
					children: city.name
				}, city.name))
			}),
			!coordsOpen && (error || calcError) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm",
				children: error || calcError
			}) : null,
			latitude != null && longitude != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-muted tabular-nums",
				children: [
					place,
					" · ",
					latitude.toFixed(4),
					", ",
					longitude.toFixed(4),
					qibla ? ` · ${qibla}` : ""
				]
			}) : null,
			slots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-4 rounded-3xl border border-line bg-surface p-5 text-sm leading-relaxed",
				children: "Set your location or enter coordinates to calculate prayer times."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: slots.map((slot) => {
					const passed = slot.at.getTime() <= now.getTime();
					const isNext = slot.name === nextName && !passed;
					const saved = slot.name === "Sunrise" ? void 0 : jamaat[slot.name];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: `rounded-3xl border border-line px-4 py-3 ${isNext ? "bg-ink" : "bg-surface"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base",
										children: slot.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: slot.name === "Sunrise" ? "Fajr time ends" : saved ? `Jamaat · ${saved}` : "Jamaat not set"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-base tabular-nums ${passed ? "text-muted" : ""}`,
									children: formatClock(slot.at)
								}),
								slot.name !== "Sunrise" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Edit ${slot.name} Jamaat`,
									onClick: () => {
										if (slot.name !== "Sunrise") openJamaat(slot.name);
									},
									className: "grid size-11 place-items-center rounded-2xl text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" })
							]
						})
					}, slot.name);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs leading-relaxed text-muted",
				children: [
					methodLabel(method),
					method === "Karachi" ? ", commonly used in South Asia" : "",
					". Asr: ",
					asr === "Shafi" ? "Shafi‘i" : "Hanafi",
					". Change either in Settings — it updates these times."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: coordsOpen,
				title: "Enter coordinates",
				onClose: () => setCoordsOpen(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Latitude",
						value: latDraft,
						onChange: setLatDraft,
						inputMode: "decimal",
						placeholder: "34.08"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Longitude",
						value: lonDraft,
						onChange: setLonDraft,
						inputMode: "decimal",
						placeholder: "74.80"
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
							onClick: () => setCoordsOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
							tone: "solid",
							onClick: saveCoords,
							children: "Save"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: jamaatPrayer != null,
				title: jamaatPrayer ? `${jamaatPrayer} Jamaat` : "Jamaat",
				onClose: () => setJamaatPrayer(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mosque time, 24-hour",
						value: jamaatDraft,
						onChange: setJamaatDraft,
						inputMode: "numeric",
						placeholder: "13:30"
					}),
					jamaatError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: jamaatError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "Leave blank to clear."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
							onClick: () => setJamaatPrayer(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextButton, {
							tone: "solid",
							onClick: saveJamaat,
							children: "Save"
						})]
					})
				]
			})
		]
	});
}
var timers = [];
function clearReminders() {
	while (timers.length > 0) {
		const id = timers.pop();
		if (id != null) window.clearTimeout(id);
	}
}
function notify(title, body) {
	try {
		if ("Notification" in window && Notification.permission === "granted") new Notification(title, { body });
	} catch {}
}
function armReminders(input) {
	clearReminders();
	const now = /* @__PURE__ */ new Date();
	let count = 0;
	for (let day = 0; day < 7; day += 1) {
		const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() + day, 12, 0, 0, 0);
		const slots = daySchedule(input.latitude, input.longitude, input.method, input.asr, date).filter((slot) => slot.name !== "Sunrise");
		for (const slot of slots) {
			if (slot.name === "Sunrise") continue;
			const name = slot.name;
			const delay = slot.at.getTime() - now.getTime();
			if (delay > 0) {
				timers.push(window.setTimeout(() => {
					notify(`Time for ${name}`, `It is time for ${name}.`);
				}, delay));
				count += 1;
			}
			const jamaat = jamaatOn(date, input.jamaat[name]);
			if (!jamaat) continue;
			const jDelay = jamaat.getTime() - now.getTime();
			if (jDelay > 0) {
				timers.push(window.setTimeout(() => {
					notify(`${slot.name} Jamaat`, "Your saved mosque Jamaat time is approaching.");
				}, jDelay));
				count += 1;
			}
		}
	}
	return count;
}
function SettingsScreen({ method, asr, reminders, latitude, longitude, jamaat, onMethod, onAsr, onReminders, onOpenDuas }) {
	const [note, setNote] = (0, import_react.useState)("");
	async function toggleReminders() {
		if (reminders) {
			onReminders(false);
			setNote("Reminders cleared.");
			return;
		}
		if (latitude == null || longitude == null) {
			setNote("Set your location in Salah first.");
			return;
		}
		if (!("Notification" in window)) {
			setNote("This browser cannot show notifications.");
			return;
		}
		if (await Notification.requestPermission() !== "granted") {
			onReminders(false);
			setNote("Permission not granted.");
			return;
		}
		const count = armReminders({
			latitude,
			longitude,
			method,
			asr,
			jamaat
		});
		onReminders(true);
		setNote(`Scheduled ${count} upcoming prayer and Jamaat reminders. They fire while Noor stays open.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium",
				children: "Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Make Noor yours"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 overflow-hidden rounded-3xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block px-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm",
								children: "Calculation method"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: "Prayer-time convention"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: method,
								onChange: (event) => onMethod(event.target.value),
								className: "mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-sm text-fg",
								children: METHODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.label
								}, item.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-4 h-px bg-line" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block px-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm",
								children: "Asr calculation"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: "Juristic convention"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: asr,
								onChange: (event) => onAsr(event.target.value),
								className: "mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-sm text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Hanafi",
									children: "Hanafi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Shafi",
									children: "Shafi‘i"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 overflow-hidden rounded-3xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": reminders,
						onClick: () => void toggleReminders(),
						className: "flex w-full items-center gap-3 px-4 py-4 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 shrink-0 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm",
									children: "Prayer reminders"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: reminders ? "On for the next seven days" : "Off · allow notifications to schedule"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								className: `relative h-7 w-12 shrink-0 rounded-full ${reminders ? "bg-fg" : "bg-ink"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 size-5 rounded-full ${reminders ? "right-1 bg-bg" : "left-1 bg-muted"}` })
							})
						]
					}),
					note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pb-4 text-xs leading-relaxed text-muted",
						children: note
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-4 h-px bg-line" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onOpenDuas,
						className: "flex w-full items-center gap-3 px-4 py-4 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "size-5 shrink-0 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm",
								children: "Duas library"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-4 h-px bg-line" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "mt-0.5 size-5 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: "Offline-first"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-muted",
							children: "Your counter, Jamaat times and settings stay on this device."
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-center text-xs tracking-widest text-muted",
				children: "NOOR 4.0 · BLACK / WHITE"
			})
		]
	});
}
var useNoor = create()(persist((set) => ({
	latitude: null,
	longitude: null,
	place: "Set your location",
	method: "Karachi",
	asr: "Hanafi",
	count: 0,
	dhikr: DEFAULT_DHIKR,
	jamaat: {},
	reminders: false,
	setPlace: (latitude, longitude, place) => set({
		latitude,
		longitude,
		place
	}),
	setMethod: (method) => set({ method }),
	setAsr: (asr) => set({ asr }),
	setCount: (count) => set({ count }),
	setDhikr: (dhikr) => set({ dhikr }),
	setJamaat: (prayer, time) => set((state) => {
		const jamaat = { ...state.jamaat };
		if (!time) delete jamaat[prayer];
		else jamaat[prayer] = time;
		return { jamaat };
	}),
	setReminders: (reminders) => set({ reminders })
}), {
	name: "noor-4",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		latitude: state.latitude,
		longitude: state.longitude,
		place: state.place,
		method: state.method,
		asr: state.asr,
		count: state.count,
		dhikr: state.dhikr,
		jamaat: state.jamaat,
		reminders: state.reminders
	})
}));
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: LayoutGrid
	},
	{
		id: "salah",
		label: "Salah",
		icon: MoonStar
	},
	{
		id: "dhikr",
		label: "Dhikr",
		icon: Fingerprint
	},
	{
		id: "quran",
		label: "Quran",
		icon: BookOpen
	},
	{
		id: "settings",
		label: "Settings",
		icon: SlidersHorizontal
	}
];
function useNow(active) {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(id);
	}, [active]);
	return now;
}
function NoorApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("home");
	const [duas, setDuas] = (0, import_react.useState)(false);
	const [tick, setTick] = (0, import_react.useState)(0);
	const now = useNow(ready);
	const latitude = useNoor((s) => s.latitude);
	const longitude = useNoor((s) => s.longitude);
	const place = useNoor((s) => s.place);
	const method = useNoor((s) => s.method);
	const asr = useNoor((s) => s.asr);
	const count = useNoor((s) => s.count);
	const dhikr = useNoor((s) => s.dhikr);
	const jamaat = useNoor((s) => s.jamaat);
	const reminders = useNoor((s) => s.reminders);
	const setPlace = useNoor((s) => s.setPlace);
	const setMethod = useNoor((s) => s.setMethod);
	const setAsr = useNoor((s) => s.setAsr);
	const setCount = useNoor((s) => s.setCount);
	const setDhikr = useNoor((s) => s.setDhikr);
	const setJamaat = useNoor((s) => s.setJamaat);
	const setReminders = useNoor((s) => s.setReminders);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const done = () => {
			if (alive) setReady(true);
		};
		const unsub = useNoor.persist.onFinishHydration(done);
		useNoor.persist.rehydrate();
		if (useNoor.persist.hasHydrated()) done();
		const backup = window.setTimeout(done, 500);
		return () => {
			alive = false;
			unsub();
			window.clearTimeout(backup);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		if (!reminders || latitude == null || longitude == null) {
			clearReminders();
			return;
		}
		if (!("Notification" in window) || Notification.permission !== "granted") return;
		armReminders({
			latitude,
			longitude,
			method,
			asr,
			jamaat
		});
		return () => clearReminders();
	}, [
		ready,
		reminders,
		latitude,
		longitude,
		method,
		asr,
		jamaat,
		tick
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-arabic text-5xl",
				children: "ن"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs tracking-widest text-muted",
				children: "NOOR"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto min-h-dvh w-full max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pb-28",
				children: duas ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DuasScreen, { onBack: () => {
					setDuas(false);
					setTab("settings");
				} }) : tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {
					now,
					latitude,
					longitude,
					place,
					method,
					asr,
					count,
					onRefresh: () => setTick((n) => n + 1),
					onOpenSalah: () => setTab("salah"),
					onOpenDhikr: () => setTab("dhikr"),
					onOpenQuran: () => setTab("quran")
				}) : tab === "salah" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalahScreen, {
					now,
					latitude,
					longitude,
					place,
					method,
					asr,
					jamaat,
					onPlace: setPlace,
					onJamaat: setJamaat
				}) : tab === "dhikr" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DhikrScreen, {
					count,
					dhikr,
					onCount: setCount,
					onDhikr: setDhikr
				}) : tab === "quran" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuranScreen, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
					method,
					asr,
					reminders,
					latitude,
					longitude,
					jamaat,
					onMethod: setMethod,
					onAsr: setAsr,
					onReminders: setReminders,
					onOpenDuas: () => setDuas(true)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "nav-pad fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface",
				"aria-label": "Primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-md grid-cols-5",
					children: TABS.map((item) => {
						const active = !duas && tab === item.id;
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": active ? "page" : void 0,
							onClick: () => {
								setDuas(false);
								setTab(item.id);
							},
							className: `flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${active ? "text-fg" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid size-8 place-items-center rounded-xl ${active ? "bg-ink" : ""}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
							}), item.label]
						}, item.id);
					})
				})
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoorApp, {});
}
//#endregion
export { Home as component };
